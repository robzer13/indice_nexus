# OROTITAN_RESEARCH_EXECUTION_PROCESS_V1 — FREEZE V1.0

**Project:** OroTitan Equity Research  
**Document type:** Execution / operating process  
**Status:** FROZEN — V1.0  
**Methodology change:** NO  
**Purpose:** Define how OroTitan research is initiated, orchestrated, persisted, transferred between stages, refreshed and published without altering the frozen analytical methodology.

---

# 0. AUTHORITY BOUNDARY

This document governs **execution**, not economic methodology.

It does not redefine:

- Discovery methodology;
- Moat Proof methodology;
- Runway methodology;
- ROIC / ROIIC methodology;
- FCF / Owner Earnings / forensic methodology;
- Capital Allocation methodology;
- Management / Governance methodology;
- Risk / Resilience methodology;
- Valuation methodology;
- Research Certification methodology;
- Scoring formulas, weights, caps or thresholds;
- OroTitan terminal eligibility;
- Investment Policy V1.0.0;
- I2 deterministic computation;
- I3-B canonical snapshot admission.

The governing doctrine remains:

> **Evidence → Calculation → Judgment → Narrative**

The purpose of this process is to make execution reproducible, auditable, persistent, recoverable and practical from ChatGPT without relying on conversational memory.

---

# 1. AUTHORITY HIERARCHY

Every stage must resolve authority in this order:

```text
1. FROZEN ANALYTICAL METHODOLOGY
2. LOCKED INVESTMENT POLICY / EXECUTION PATCHES / I2 / I3-B
3. OROTITAN_RESEARCH_EXECUTION_PROCESS_V1
4. VERSIONED STAGE CONTRACT
5. RUN-SPECIFIC BOOTSTRAP
```

A lower layer may specialize execution but may never override a higher layer.

If a lower layer conflicts with a higher layer:

```text
CONTRACT_DRIFT = DETECTED
→ FAIL CLOSED
→ STOP
→ RETURN TO PILOTAGE
```

No prompt, bootstrap, conversational summary or stage artifact may silently redefine the frozen method.

---

# 2. DESIGN OBJECTIVE

The user experience must remain simple even when the internal process is demanding.

Target interaction:

```text
User
→ types a company name in 00 — PILOTAGE

00 — PILOTAGE
→ resolves company identity
→ resolves canonical mode / run type
→ inspects canonical state
→ prepares the run
→ provides the exact next-stage bootstrap

RESEARCH
→ builds the evidence base
→ proves DD input sufficiency

DEEP DIVE
→ executes frozen analytical methodology
→ values
→ certifies
→ scores if permitted
→ runs terminal gate

INTEGRATION
→ builds and validates canonical snapshot

User
→ GO PUBLISH <COMPANY>

Production
→ new canonical state becomes current
→ prior history remains immutable
```

The user should not need to manually reconstruct context between stages.

---

# 3. USER ENTRY PATHS VS CANONICAL MODES

The execution process exposes two user entry paths. They are **not new OroTitan analytical modes**.

## 3.1 ENTRY_PATH = DISCOVERY_TO_DECISION

The user does not impose a company.

```text
UNIVERSE
→ DISCOVERY
→ PRE-SCREEN
→ DEEP_DIVE_CANDIDATE(S)
→ HEAVY RESEARCH
→ DEEP DIVE
→ INTEGRATION
```

Canonical mode mapping:

```text
DISCOVERY_TO_DECISION
→ DISCOVER
or
→ DISCOVER + ANALYZE
```

Discovery remains broad and relatively fast. Imperfect data are acceptable where the frozen Discovery standard permits them.

Heavy Research may begin only for a candidate that reaches:

```text
DECISION_STATUS = DEEP_DIVE_CANDIDATE
```

Discovery signals and hypotheses remain falsifiable. They do not become Deep Dive truth by passage through the routing layer.

## 3.2 ENTRY_PATH = IMPOSED_COMPANY

The user names a company directly.

Example:

```text
RATIONAL AG
```

If no canonical dossier exists:

```text
CANONICAL MODE = ANALYZE
```

No Discovery pre-screen is required.

The execution path becomes:

```text
USER SELECTS COMPANY
→ HEAVY RESEARCH
→ DEEP DIVE
→ INTEGRATION
```

The user’s decision to impose the company accepts the research cost. It does not pre-judge business quality or investment attractiveness.

## 3.3 Existing company

If the user types a bare company name in Pilotage and a canonical dossier already exists, the Pilotage UX defaults to:

```text
CANONICAL MODE = REFRESH
```

If the user explicitly asks whether a prepared dossier has become actionable because of a price move or pre-identified price-zone event:

```text
CANONICAL MODE = ACTIVATION CHECK
```

The Pilotage UX convention must not replace the frozen global mode resolver.

---

# 4. 00 — PILOTAGE

## 4.1 Role

`00 — PILOTAGE` is a permanent orchestration discussion.

```text
00 — PILOTAGE
= ORCHESTRATION
≠ COMPANY RESEARCH
≠ COMPANY ANALYSIS
≠ SOURCE OF ANALYTICAL TRUTH
```

Its responsibilities are limited to:

- resolve issuer/security identity sufficiently to route the work;
- resolve entry path and canonical mode;
- detect INITIAL vs REFRESH / ACTIVATION;
- inspect current canonical state;
- create or resolve the active run;
- identify authoritative artifacts;
- identify the applicable Stage Contract;
- generate the next bootstrap prompt;
- enforce stage order;
- surface blockers;
- request user authorization only where required.

Pilotage must not reconstruct a company thesis from its own conversation history.

## 4.2 User interaction

For a new imposed company, Pilotage should return a concise pre-run card:

```text
COMPANY = <resolved issuer>
ENTRY_PATH = IMPOSED_COMPANY
CANONICAL_MODE = ANALYZE
RUN_TYPE = INITIAL
EXISTING_CANONICAL_DOSSIER = NONE

PIPELINE:
1. RESEARCH
2. DEEP DIVE
3. INTEGRATION

NO PRODUCTION PROMOTION BEFORE SEPARATE GO PUBLISH.
```

Then request one execution authorization:

```text
GO <COMPANY>
```

After that GO, the analytical workflow may proceed through Research, Deep Dive and Integration without repeated micro-authorizations, except where a true user decision or sensitive action is required.

Production publication remains separately authorized:

```text
GO PUBLISH <COMPANY>
```

---

# 5. RUN MODEL

## 5.1 Maximum three execution discussions per run

For each initial analysis or refresh:

```text
<COMPANY> — RESEARCH — <RUN>
<COMPANY> — DEEP DIVE — <RUN>
<COMPANY> — INTEGRATION — <RUN>
```

The objective is:

```text
FRESH CONVERSATIONAL CONTEXT
+
PERSISTENT CANONICAL KNOWLEDGE
```

not:

```text
ONE PERMANENT COMPANY THREAD
+
ACCUMULATED CONTEXT CONTAMINATION
```

## 5.2 Run identifier

After the user gives the execution GO and before Research begins, the run receives one persistent `RUN_ID` that remains stable across all three execution stages.

The exact identifier syntax is an implementation detail.

## 5.3 Point-in-time boundary

Every analytical run must establish one explicit `DATA_CUTOFF`.

Default execution rule:

```text
IF user explicitly requests a historical cutoff
→ use that cutoff

ELSE
→ DATA_CUTOFF = run initiation date
```

Post-cutoff information must not contaminate the run.

If materially later information is to be incorporated, create a new run / refresh with a new cutoff.

Keep distinct:

```text
DATA_CUTOFF
REFERENCE_PRICE_DATE
CALCULATION_DATE
```

according to the frozen methodology and integration contract.

---

# 6. PERSISTENT-STATE ARCHITECTURE

## 6.1 Core principle

```text
CHATGPT DISCUSSIONS
= execution workers

PERSISTED ARTIFACTS
= durable research memory

CANONICAL SNAPSHOT
= product truth
```

No stage may depend on a chain of conversational summaries as authoritative analytical input.

## 6.2 Target storage split

### GitHub

Recommended for:

- canonical Stage Contracts;
- bootstrap templates;
- Markdown analytical artifacts;
- machine-readable manifests;
- version history;
- provenance;
- auditable diffs.

### Supabase

Recommended for:

- run registry;
- stage state;
- artifact registry;
- exact artifact identifiers / versions;
- GitHub paths / commit references / integrity metadata;
- canonical snapshot state;
- `current_snapshot_id`;
- product-facing canonical state.

Conceptually:

```text
GitHub
= document archive + contracts + versioning

Supabase
= operational registry + canonical product state
```

The exact physical persistence model is an implementation decision, provided the authority and immutability rules in this process are preserved.

---

# 7. STAGE CONTRACTS AND BOOTSTRAPS

Each execution discussion uses:

```text
SHORT RUN-SPECIFIC BOOTSTRAP
+
VERSIONED CANONICAL STAGE CONTRACT
```

Target contracts:

```text
RESEARCH_STAGE_CONTRACT
DEEP_DIVE_STAGE_CONTRACT
INTEGRATION_STAGE_CONTRACT
```

Pilotage itself should eventually be governed by a versioned orchestration contract.

The run-specific bootstrap identifies at minimum:

- company / issuer identity;
- `RUN_ID`;
- canonical mode;
- stage;
- expected Stage Contract version;
- exact input artifact identities where applicable;
- `DATA_CUTOFF`;
- critical invariants.

The Stage Contract contains the full operating behavior.

---

# 8. MANDATORY PRE-FLIGHT

Every execution discussion begins with:

```text
1. Resolve RUN_ID.
2. Load authoritative run state.
3. Load exact required Stage Contract.
4. Verify Stage Contract version.
5. Retrieve every required input artifact by exact identity.
6. Verify artifact RUN_ID / VERSION / STATUS.
7. Verify DATA_CUTOFF consistency.
8. Verify higher-authority contract compatibility.
9. Verify no blocking precondition remains open.
```

If any mandatory check fails:

```text
PRE_FLIGHT = FAIL
→ STOP
→ DO NOT ANALYZE
→ REPORT EXACT FAILURE
→ RETURN TO PILOTAGE
```

The bootstrap prompt is never analytical evidence.

---

# 9. RESEARCH STAGE — PURPOSE

Research exists to make the Deep Dive executable at institutional evidence quality.

Research performs:

```text
COLLECT
→ NORMALIZE
→ VERIFY
→ CHALLENGE
→ IDENTIFY GAPS
→ CLOSE GAPS WHERE REASONABLY POSSIBLE
→ DETERMINE DD INPUT SUFFICIENCY
```

Research may formulate research hypotheses, but it does not issue final Deep Dive verdicts.

Research does not score the company.

---

# 10. RESEARCH INPUT MODEL

## 10.1 User-provided documents + autonomous search

The operating model is mixed:

1. User may attach any documents already possessed.
2. Research inventories and classifies them.
3. Research autonomously searches for missing primary and external evidence.
4. Research explores reasonable alternative sources before asking the user for help.
5. User assistance is requested only for a critical input that remains inaccessible after reasonable attempts.

The user is not required to know the full documentary checklist in advance.

## 10.2 Adaptive collection standard

Research uses:

```text
UNIVERSAL CORE
+
COMPANY / BUSINESS-MODEL / SECTOR ADAPTATION
```

There is no arbitrary universal rule such as “10 Annual Reports for every company.”

The governing question is:

> Do we have enough evidence to execute each required analytical block properly?

---

# 11. ONE AUTHORITATIVE EVIDENCE LEDGER

There is one authoritative Evidence Ledger for a run.

Do not create competing authorities such as separate primary and external ledgers.

Issuer, competitor, customer, regulator, technical, academic and market evidence may be represented as filtered views or sections of the same ledger.

For every material claim, preserve the frozen Evidence Ledger semantics, including:

```text
EVIDENCE_ID
CLAIM_ID
CLAIM / METRIC
VALUE / STATEMENT
PERIOD / AS_OF_DATE
SOURCE
ROOT_SOURCE_ID
INDEPENDENCE_GROUP
SOURCE_CLASS
CLAIM_FIT
SOURCE_DATE
DATA_CUTOFF
EPISTEMIC_TYPE
FRESHNESS_STATE
LIMITATIONS
CONFLICT_STATUS
```

The Research stage initializes and enriches this ledger.

The Deep Dive may append new evidence and version the same authoritative ledger.

---

# 12. RESEARCH HYPOTHESES

Research may formulate hypotheses to direct evidence collection.

```text
MATERIAL RESEARCH HYPOTHESIS
→ MUST BE FORMALIZED

TACTICAL RESEARCH HYPOTHESIS
→ MAY REMAIN INFORMAL
```

A material hypothesis is one that could materially affect a Deep Dive block or final conclusion.

Recommended execution structure:

```text
HYPOTHESIS_ID
ANALYSIS_BLOCK
HYPOTHESIS
WHY_MATERIAL
SUPPORTING_EVIDENCE_IDS[]
CONTRADICTING_EVIDENCE_IDS[]
UNRESOLVED_POINTS[]
RESEARCH_STATUS
```

Example permitted during Research:

> The service network could represent a barrier to entry.

Example prohibited as a Research-stage final verdict:

> The company has a durable service moat.

---

# 13. DD INPUT SUFFICIENCY GATE

## 13.1 Execution-only semantics

The process introduces:

```text
DD_INPUT_SUFFICIENCY
READY_FOR_DEEP_DIVE
```

These are execution-layer concepts only.

They are distinct from:

```text
DISCOVERY.DATA_SUFFICIENCY
DOSSIER_READINESS
BUSINESS_RESEARCH_STATUS
INVESTMENT_CONCLUSION_STATUS
SCORE_PERMISSION
```

They must not be written into frozen analytical fields unless a future explicit integration contract adds them.

## 13.2 INITIAL analysis / FULL REFRESH

`READY_FOR_DEEP_DIVE = YES` only when every required DD input block is sufficient.

Target execution blocks:

```text
IDENTITY_PIT_INPUTS
BUSINESS_MODEL_INPUTS
MOAT_INPUTS
RUNWAY_INPUTS
RETURN_QUALITY_INPUTS
FCF_FORENSIC_INPUTS
CAPITAL_ALLOCATION_INPUTS
MANAGEMENT_GOVERNANCE_INPUTS
OUTSIDE_VIEW_INPUTS
RISK_RESILIENCE_INPUTS
VALUATION_INPUTS
```

Allowed execution sufficiency states:

```text
SUFFICIENT
INSUFFICIENT
NOT_APPLICABLE
```

A required block cannot pass on `PARTIALLY_SUFFICIENT`.

## 13.3 Targeted refresh

For `ROUTINE_FUNDAMENTAL_DELTA`:

```text
REOPENED BLOCKS
+
MATERIAL DOWNSTREAM DEPENDENCIES
= SUFFICIENT
```

before affected Deep Dive work proceeds.

For `PRICE_ONLY_DELTA`, unaffected fundamental blocks are not artificially re-researched.

## 13.4 Meaning of SUFFICIENT

For every required block:

```text
SUFFICIENT
=
MANDATORY COVERAGE
+
EVIDENCE ADEQUACY
+
NO MATERIAL BLOCKING GAP
```

with:

```text
UNIVERSAL BLOCK STANDARD
+
SECTOR / BUSINESS-MODEL OVERLAY
```

Input sufficiency is not the future verdict.

```text
MOAT_INPUTS = SUFFICIENT
≠
MOAT = STRONGLY_SUPPORTED
```

A sufficiently researched block may later receive a negative conclusion.

---

# 14. GAP-CLOSING LOOP

When a required input block is insufficient:

```text
INSUFFICIENT
→ TARGETED SEARCH
→ SOURCE DIVERSIFICATION
→ NEGATIVE / CONTRADICTORY SEARCH
→ RE-EVALUATION
```

Repeat until:

```text
SUFFICIENT
```

or:

```text
REASONABLY AVAILABLE SOURCES EXHAUSTED
```

If adequate work has been performed but the critical evidence remains unavailable:

```text
RESEARCH_STAGE_STATUS = BLOCKED_INSUFFICIENT_INPUT
READY_FOR_DEEP_DIVE = NO
```

This is not `REJECTED` and is not evidence of a weak business.

Unknowns remain unknown. The system may not manufacture an assumption solely to finish the workflow.

---

# 15. CRITICAL MISSING INPUT — USER ASSISTANCE

If a truly critical input cannot be obtained autonomously:

```text
CRITICAL INPUT MISSING
→ RESEARCH = PAUSED
→ GLOBAL PAUSE
→ USER ASSISTANCE REQUEST
```

Research does not continue other work while waiting.

The request must state:

```text
DOCUMENT / DATA REQUIRED
WHY REQUIRED
SEARCH ALREADY ATTEMPTED
ACCEPTABLE SUBSTITUTE
IMPACT IF UNAVAILABLE
```

The user may upload the requested material in the same Research discussion and simply write:

```text
voilà
```

Research must then:

- identify the material;
- associate it with the active run;
- register / archive it according to the stage contract;
- re-evaluate the blocker;
- resume from the paused state without a new full prompt.

---

# 16. RESEARCH-STAGE AUTHORITATIVE OUTPUTS

At minimum, Research should persist:

```text
SOURCE MANIFEST
EVIDENCE LEDGER
RESEARCH HYPOTHESIS REGISTER
RESEARCH GAP REGISTER
DD INPUT READINESS REPORT / LOCK
```

The exact storage representation may evolve, but the authoritative semantics may not conflict with the frozen Analysis Standard.

The Research stage may additionally persist normalized source inventories and views as implementation aids.

---

# 17. RESEARCH-STAGE COMPLETION

A Research stage is complete only if its required work and persistence obligations are complete.

At user-facing completion it produces:

## 17.1 Human summary

Approximately 10–15 lines covering:

- what was found;
- important contradictions / falsifications;
- remaining non-blocking limitations;
- overall evidence quality;
- any user-supplied critical item resolved;
- `READY_FOR_DEEP_DIVE`.

This summary is for the user.

It is not the authoritative input to Deep Dive.

## 17.2 Pilotage fallback handoff

Compact fallback:

```text
COMPANY
RUN_ID
STAGE = RESEARCH
STAGE_STATUS
READY_FOR_DEEP_DIVE
AUTHORITATIVE_ARTIFACT_IDS / VERSIONS
CRITICAL_BLOCKERS
NEXT_STAGE
```

Normal path:

```text
Pilotage retrieves persisted run/artifact state.
```

Fallback path:

```text
User supplies exact PILOTAGE HANDOFF.
```

Large analytical copy-paste is not part of the normal workflow.

---

# 18. DEEP DIVE ADMISSION

Deep Dive may begin only when:

```text
READY_FOR_DEEP_DIVE = YES
```

and the Deep Dive discussion independently passes its own pre-flight.

Research-stage sufficiency authorizes work to begin. It does not permanently guarantee that every question is resolved.

---

# 19. CANONICAL DEEP DIVE ORDER

The frozen dependency order remains authoritative:

```text
0. IDENTITY / POINT-IN-TIME LOCK
1. EVIDENCE LEDGER
2. BUSINESS / SEGMENT / ECONOMIC MODEL
3. ECONOMIC QUALITY SYNTHESIS
4. MOAT PROOF
5. GROWTH / RUNWAY
6. RETURN ON CAPITAL / MARGINAL RETURN
7. FCF / OWNER EARNINGS / FORENSIC
8. CAPITAL ALLOCATION
9. MANAGEMENT / GOVERNANCE
10. OUTSIDE VIEW / BASE RATES
11. RISK / RESILIENCE
12. RED TEAM / PRE-MORTEM
13. VALUATION / EXPECTED RETURN
14. RESEARCH CERTIFICATION
15. SCORING
16. OROTITAN TERMINAL GATE
17. READINESS / NEXT ACTION
```

In particular:

```text
VALUATION FINALIZATION
cannot precede required fundamental inputs

CERTIFICATION
cannot precede required analysis

SCORING
cannot precede Certification permission
```

The execution process may optimize concurrency but may not invert this dependency chain.

---

# 20. LEAD ANALYST + SPECIALIST BLOCKS

Recommended Deep Dive execution architecture:

```text
ONE LEAD ANALYST
+
SPECIALIST ANALYTICAL BLOCKS
```

Lead Analyst responsibilities:

- orchestrate the dossier;
- manage dependencies;
- reconcile contradictions;
- control block re-openings;
- enforce frozen methodology;
- perform cross-block reconciliation;
- own the dossier-level conclusion.

Specialist blocks may include:

```text
MOAT
RUNWAY
RETURN QUALITY
FCF / FORENSIC
CAPITAL ALLOCATION
MANAGEMENT / GOVERNANCE
OUTSIDE VIEW / BASE RATES
RISK / RESILIENCE
VALUATION
```

This specialization is internal to the Deep Dive discussion. The user does not manage a separate ChatGPT discussion for every analytical block.

---

# 21. SAFE PARALLELIZATION

Blocks may advance in parallel where dependencies genuinely permit.

```text
PARALLELIZE WHEN DEPENDENCIES ALLOW
DO NOT BYPASS ECONOMIC DEPENDENCIES
```

Parallel work is an execution optimization only.

It must not change:

- the frozen methodology;
- required inputs;
- certification order;
- scoring permission;
- terminal-gate logic.

---

# 22. BLOCK EXECUTION LIFECYCLE

The execution process may use:

```text
INSUFFICIENT
IN_PROGRESS
PROVISIONALLY_STABLE
LOCKED
```

These are **execution metadata only**.

They do not replace the frozen Certification block-execution vocabulary:

```text
COMPLETE
COMPLETE_WITH_LIMITATIONS
NOT_APPLICABLE
MISSING
```

At Certification, the frozen vocabulary is authoritative.

## 22.1 PROVISIONALLY_STABLE

A provisionally stable block may feed dependent work while remaining revisable.

It should expose only material:

```text
MATERIAL_DEPENDENCIES[]
REOPEN_TRIGGERS[]
```

## 22.2 LOCKED

`LOCKED` means finalized for the current analytical run before Certification mapping.

It does not itself equal `CERTIFIED`.

---

# 23. EXECUTION CONFIDENCE METADATA

A block may carry:

```text
CONFIDENCE = HIGH | MEDIUM | LOW
```

This is a global analyst execution judgment with a short rationale.

It is distinct from and must not silently replace:

```text
EVIDENCE_GRADE
DATA_QUALITY
VALUATION_RELIABILITY
FORENSIC_RELIABILITY
CERTIFICATION STATUS
QUALITY SCORE
OVS INPUT
OROTITAN GATE INPUT
```

No numerical confidence sub-score is required.

Unless a future canonical integration contract explicitly adds it, this execution-confidence field is not written into the frozen Phase-4 analytical schema.

---

# 24. STANDARD BLOCK EXECUTION OUTPUT

Each analytical block should expose a structured execution envelope plus free-form rationale.

Conceptual minimum:

```text
BLOCK_ID
BLOCK_VERSION

EXECUTION_STATUS
EXECUTION_CONFIDENCE
CANONICAL_VERDICT_FIELDS[]

CORE_FINDINGS[]
SUPPORTING_EVIDENCE_IDS[]
CONTRADICTING_EVIDENCE_IDS[]

MATERIAL_ASSUMPTION_IDS[]
UNRESOLVED_POINTS[]

MATERIAL_DEPENDENCIES[]
REOPEN_TRIGGERS[]

RATIONALE
LAST_RESEARCH_DATE
DATA_CUTOFF
```

`CANONICAL_VERDICT_FIELDS[]` must use the frozen analytical vocabulary for that block. The execution envelope must not invent alternate analytical semantics.

`RATIONALE` preserves the full economic reasoning.

---

# 25. NEW RESEARCH DURING DEEP DIVE

Every specialist block has access to the full evidence corpus.

Specialists may launch targeted new research when they identify:

- a gap;
- a contradiction;
- a new material hypothesis;
- a necessary counterfactual;
- an unresolved definition;
- or a relevant negative-evidence question.

Any new material evidence must enter the authoritative Evidence Ledger with frozen provenance semantics before being relied upon materially.

A discovered source is not automatically material evidence.

---

# 26. INTER-BLOCK COMMUNICATION

Specialist blocks do not freely exchange persuasive narratives as authority.

Allowed cross-block inputs include:

- facts;
- calculations;
- identified assumptions;
- structured findings;
- necessary provisional canonical verdicts;
- limitations;
- execution status.

Not accepted as automatic cross-block authority:

- global conviction language;
- persuasive narrative;
- expected score;
- investment conclusion.

The Lead Analyst owns cross-block reconciliation.

---

# 27. FROZEN CONFLICT, CALCULATION AND ASSUMPTION CONTROLS

The execution process does not redesign these controls.

## 27.1 Conflict Ledger

Preserve the frozen semantics:

```text
CONFLICT_ID
METRIC / CLAIM
SOURCE_A
VALUE_A
EVIDENCE_ID_A
SOURCE_B
VALUE_B
EVIDENCE_ID_B
CONFLICT_TYPE
REASON
RESOLUTION
MATERIALITY
AFFECTED_OUTPUTS[]
```

Never choose the convenient number silently.

A material unresolved conflict blocks the affected certification/output as defined by the frozen methodology.

## 27.2 Calculation Ledger

Preserve:

```text
CALCULATION_ID
METRIC_NAME
FORMULA
INPUTS[]
INPUT_EVIDENCE_IDS[]
UNITS
CURRENCY
PERIOD
BASIS
RAW_RESULT
ROUNDING_RULE
PUBLISHED_RESULT
METHOD_VERSION
CALCULATION_VERSION
AUTOMATED_CHECK_STATUS
LIMITATIONS
```

Material calculations must remain independently reproducible.

## 27.3 Material assumptions

Preserve:

```text
ASSUMPTION_ID
VARIABLE
VALUE / RANGE
EPISTEMIC_TYPE
SOURCE / RATIONALE
SENSITIVITY
USED_IN
```

Assumption leakage into factual narrative is prohibited.

Implementation may choose how and where to persist these objects. It may not redesign their semantics without a higher-authority methodology change.

---

# 28. DYNAMIC SUFFICIENCY AND REOPENING

`READY_FOR_DEEP_DIVE = YES` permits Deep Dive execution to begin.

It does not permanently certify every input.

If new evidence reveals:

- a material gap;
- a material unresolved contradiction;
- a failed material assumption;
- a previously hidden critical question;
- or a definition/basis mismatch;

then the affected block may move:

```text
SUFFICIENT
→ INSUFFICIENT
```

and/or:

```text
PROVISIONALLY_STABLE / LOCKED
→ REOPEN
```

The affected analytical work is suspended and returns to research.

It may resume only when the required sufficiency is restored or the frozen methodology explicitly permits an honest unavailable / not-assessable state.

Nothing remains true merely because it was previously accepted.

---

# 29. DEEP DIVE COMPLETION

The frozen final dependency remains:

```text
RED TEAM / PRE-MORTEM
→ VALUATION / EXPECTED RETURN
→ RESEARCH CERTIFICATION
→ SCORING IF PERMITTED
→ OROTITAN TERMINAL GATE
→ READINESS / NEXT ACTION
```

At completion, persist the analytical artifacts required by the Stage Contract, including the canonical evidence/calculation/assumption/conflict references required for traceability.

The Deep Dive then produces to the user:

## 29.1 Human summary

Approximately 10–15 lines covering:

- economic thesis;
- strongest evidence;
- material weaknesses;
- key risks;
- key uncertainties;
- Certification outcome;
- scoring / valuation if permitted;
- OroTitan terminal result;
- readiness / next action.

## 29.2 Pilotage fallback handoff

```text
COMPANY
RUN_ID
STAGE = DEEP_DIVE
STAGE_STATUS
CERTIFICATION STATUS
SCORE_PERMISSION
READY_FOR_INTEGRATION
AUTHORITATIVE_ARTIFACT_IDS / VERSIONS
CRITICAL_BLOCKERS
NEXT_STAGE
```

The human summary is not the Integration input. Persisted certified artifacts are.

---

# 30. INTEGRATION STAGE

Integration is technical/canonical, not an analytical substitute.

It must retrieve the exact certified Deep Dive artifacts and pass its own pre-flight.

Target flow:

```text
CERTIFIED / PERMITTED DEEP DIVE OUTPUT
→ PHASE-4 SNAPSHOT BUILD
→ SCHEMA VALIDATION
→ I2 RECONCILIATION
→ I3-B ADMISSION VALIDATION
→ PRE-PUBLICATION CONTROL
→ STOP
```

Integration may not repair a methodology or evidence defect by silently changing analytical outputs.

If a defect is analytical, return to the appropriate upstream stage.

---

# 31. PRE-PUBLICATION CONTROL

Before publication, show the user a concise control card containing decision-useful and technical fields, for example:

```text
COMPANY
DATA_CUTOFF
BUSINESS_RESEARCH_STATUS
INVESTMENT_CONCLUSION_STATUS
SCORE_PERMISSION
OQS
OVS / INVESTMENT_SCORE if available
OROTITAN_STATUS
FAIR_VALUE / RANGE
PRIMARY_EXPECTED_RETURN
NEXT_ACTION

SCHEMA_VALIDATION
I2_RECONCILIATION
I3B_ADMISSION

READY_TO_PUBLISH = YES / NO
```

This is the final human checkpoint before production promotion.

---

# 32. PUBLICATION AUTHORIZATION

Only:

```text
GO PUBLISH <COMPANY>
```

authorizes production persistence / promotion of the prepared canonical snapshot.

After publication:

```text
NEW SNAPSHOT
→ becomes current canonical state

PRIOR SNAPSHOTS
→ remain immutable history
```

No analytical GO implicitly authorizes production publication.

---

# 33. SITE BEHAVIOR

## 33.1 Main interface

Show only the latest canonical state.

## 33.2 Individual company page

Permit historical inspection of prior canonical snapshots and block evolution.

Historical states must be clearly separated from current canonical state.

The exact UI is an implementation concern.

---

# 34. REFRESH PROCESS

## 34.1 Start with delta discovery

Every normal refresh begins with:

```text
WHAT CHANGED SINCE LAST CANONICAL SNAPSHOT?
```

Search at minimum for relevant changes in:

- financial reporting;
- guidance;
- business model;
- management;
- governance;
- capital allocation;
- M&A;
- competition;
- products / technology;
- regulation;
- market structure;
- material risks;
- valuation inputs;
- prior invalidation / reactivation triggers.

## 34.2 Frozen refresh classifier

Classify the update as:

```text
PRICE_ONLY_DELTA
ROUTINE_FUNDAMENTAL_DELTA
FULL_REFRESH_REQUIRED
```

Then execute only the required work and downstream dependencies.

### PRICE_ONLY_DELTA

Do not rerun unaffected fundamental quality blocks merely because price changed.

### ROUTINE_FUNDAMENTAL_DELTA

Reopen affected blocks and their material downstream dependencies.

### FULL_REFRESH_REQUIRED

Re-establish all required DD input blocks before the full affected Deep Dive chain proceeds.

An explicit prepared-price activation question uses `ACTIVATION CHECK`, not generic Refresh.

## 34.3 Manual impact assessment

The analyst decides case by case which blocks are affected and which downstream dependencies materially require reopening.

No automatic dependency matrix has authority to make that final analytical judgment.

Automation may assist, but analyst judgment remains authoritative.

---

# 35. REUSE OF PRIOR CANONICAL RESEARCH

Core principle:

```text
PREVIOUS CANONICAL RESEARCH
= KNOWLEDGE BASE
≠ CURRENT EVIDENCE BY DEFAULT
```

The system should exploit accumulated knowledge to work more intelligently, but no material conclusion receives a permanent presumption of truth.

Material inherited conclusions, assumptions, risks and thesis drivers must be revalidated when they are relied upon in the new canonical snapshot.

Useful execution labels may include:

```text
REVALIDATED
UPDATED
SUPERSEDED
INVALIDATED
```

There is no requirement to tag every immaterial historical fact.

A targeted refresh still produces a new immutable global canonical snapshot after the required downstream reconciliation and recertification.

---

# 36. ARTIFACT RETRIEVAL RULE

Inter-stage transfer must use exact persisted identity:

```text
ARTIFACT_ID
VERSION
STATUS
RUN_ID
```

plus integrity metadata where available.

Do not use:

```text
"latest file that looks right"
filename guessing
conversation-memory reconstruction
summary reconstruction
```

If automated retrieval is unavailable, the exact persisted artifact may be supplied manually as fallback.

A human summary is never a substitute for the authoritative artifact.

---

# 37. STAGE FINALIZATION — COMMIT-LIKE RULE

A stage may be declared `COMPLETE` only after:

```text
1. REQUIRED WORK COMPLETE
2. STAGE SELF-AUDIT COMPLETE
3. REQUIRED ARTIFACTS GENERATED
4. ARTIFACTS PERSISTED / VERSIONED
5. REGISTRY RECONCILED
6. STAGE STATUS UPDATED
7. NEXT-STAGE ELIGIBILITY DECLARED
8. HUMAN SUMMARY PRODUCED
9. PILOTAGE FALLBACK HANDOFF PRODUCED
10. STOP AT STAGE BOUNDARY
```

If persistence or registry reconciliation fails:

```text
STAGE_STATUS ≠ COMPLETE
```

The failure must be explicit and retryable.

A stage is not complete merely because a narrative answer was generated.

---

# 38. HUMAN INTERACTION PHILOSOPHY

The system should be highly autonomous.

It should not ask the user to approve methodological choices that can be resolved objectively under the frozen method.

User involvement should be reserved for:

- critical inaccessible source/data requests;
- true investment-policy choices;
- genuinely subjective user choices;
- high-impact / sensitive actions;
- final publication authorization.

No micro-validation workflow.

---

# 39. FAIL-CLOSED RULES

At minimum:

```text
MISSING CRITICAL INPUT
→ PAUSE

REQUIRED DD INPUT BLOCK INSUFFICIENT
→ NO AFFECTED DEEP DIVE EXECUTION

PRE-FLIGHT FAILURE
→ NO STAGE EXECUTION

MATERIAL UNRESOLVED CONFLICT
→ AFFECTED OUTPUT CANNOT BE CERTIFIED / LOCKED AS APPLICABLE

CONTRACT VERSION MISMATCH
→ STOP

ARTIFACT VERSION / ID MISMATCH
→ STOP

POST-CUTOFF EVIDENCE ATTEMPTED AS RUN EVIDENCE
→ REJECT FROM CURRENT RUN / REQUIRE NEW CUTOFF RUN IF MATERIAL

SCORE_PERMISSION != ALLOWED
→ NO FINAL NUMERIC SCORE WHERE FROZEN METHOD PROHIBITS IT

INTEGRATION VALIDATION FAILURE
→ NO PUBLICATION

NO GO PUBLISH
→ NO PRODUCTION PROMOTION
```

Unknowns must remain unknown.

---

# 40. END-TO-END STATE MACHINE

```text
USER INTENT
        ↓
00 — PILOTAGE
        ↓
ENTRY PATH + CANONICAL MODE RESOLUTION
        ↓
PRE-RUN PLAN
        ↓
USER GO
        ↓
RUN CREATED + DATA_CUTOFF LOCKED
        ↓
RESEARCH
        ↓
DD INPUT SUFFICIENCY GATE
        ├── NO → SEARCH / PAUSE / USER INPUT / BLOCKED
        └── YES
              ↓
          DEEP DIVE
              ↓
          CANONICAL ANALYTICAL ORDER
              ↓
          DYNAMIC REOPEN IF NEEDED
              ↓
          VALUATION
              ↓
          CERTIFICATION
              ↓
          SCORING IF PERMITTED
              ↓
          TERMINAL GATE
              ↓
          READINESS / NEXT ACTION
              ↓
          INTEGRATION
              ↓
          SNAPSHOT VALIDATION
              ↓
          PRE-PUBLISH CARD
              ↓
          USER GO PUBLISH
              ↓
          CANONICAL PERSISTENCE / PROMOTION
              ↓
          SITE CURRENT STATE + IMMUTABLE HISTORY
```

For Refresh, insert the frozen delta classifier before deciding the required Research / Deep Dive scope.

---

# 41. STAGE CONTRACT VALIDATION REQUIREMENT

No Stage Contract may be frozen merely because its prose appears comprehensive.

Before Stage Contract freeze, run a dedicated regression campaign including at least:

```text
INITIAL IMPOSED COMPANY
DISCOVERY → DEEP_DIVE_CANDIDATE HANDOFF
LOW-DISCLOSURE COMPANY
CRITICAL DOCUMENT MISSING
POST-CUTOFF SOURCE ATTEMPT
MATERIAL SOURCE CONFLICT
CONTRACT VERSION MISMATCH
ARTIFACT VERSION MISMATCH
ARTIFACT RETRIEVAL FAILURE
ROUTINE FUNDAMENTAL REFRESH
FULL REFRESH REQUIRED
PRICE_ONLY_DELTA
ACTIVATION CHECK
BLOCK REOPEN AFTER CONTRADICTORY EVIDENCE
SCORE_PERMISSION SUSPENDED
INTEGRATION VALIDATION FAILURE
STAGE FINALIZATION FAILURE
```

Required invariants:

```text
NO METHODOLOGY DRIFT
NO SILENT ASSUMPTION CREATION
NO SUMMARY-AS-AUTHORITY
NO DIRECT-MAIN WRITE
NO PRODUCTION PROMOTION WITHOUT GO PUBLISH
DETERMINISTIC I2 OUTPUTS EXACT
CORRECT FAIL-CLOSED BEHAVIOR
```

---

# 42. IMPLEMENTATION DETAILS INTENTIONALLY LEFT OPEN

The following are engineering decisions, provided they respect this process and higher authorities:

- exact run-registry SQL schema;
- exact GitHub folder layout;
- exact artifact-ID syntax;
- exact run-ID syntax;
- exact stage-manifest schema;
- exact hashing/fingerprinting mechanism;
- exact connector/retrieval implementation;
- exact UX for optional progress queries;
- optional dependency suggestions;
- prompt-template storage paths;
- transaction implementation for stage finalization;
- physical persistence layout for the already-frozen Evidence / Conflict / Calculation / Assumption semantics.

The semantics of the frozen ledgers are **not** open implementation questions.

---

# 43. V1 USER-EXPERIENCE SUCCESS CRITERION

The target operation is approximately:

```text
User:
RATIONAL AG

Pilotage:
resolves issuer
→ detects INITIAL or REFRESH
→ displays concise plan

User:
GO RATIONAL

Pilotage:
→ creates/resolves run
→ supplies exact Research bootstrap

Research:
→ inventories user documents
→ autonomously gathers remaining evidence
→ asks user only for truly critical inaccessible input
→ persists authoritative artifacts
→ READY_FOR_DEEP_DIVE = YES

Pilotage:
→ retrieves persisted Research state
→ supplies exact Deep Dive bootstrap

Deep Dive:
→ independently retrieves exact artifacts
→ executes frozen analytical order
→ performs fresh targeted research where needed
→ values
→ certifies
→ scores if permitted
→ runs terminal gate
→ persists outputs

Pilotage:
→ retrieves Deep Dive state
→ supplies exact Integration bootstrap

Integration:
→ builds and validates snapshot
→ READY_TO_PUBLISH = YES

User:
GO PUBLISH RATIONAL

System:
→ persists/promotes canonical snapshot
→ site displays latest canonical state
→ prior snapshots remain historical
```

The user never needs to manually reconstruct analytical context between stages.

---

# 44. PROCESS DECISIONS ESTABLISHED

The following execution decisions are incorporated in v0.2:

1. Two user entry paths: Discovery-to-Decision and Imposed-Company.
2. Canonical mode vocabulary remains frozen and separate from entry paths.
3. Discovery heavy-research handoff requires `DEEP_DIVE_CANDIDATE`.
4. Imposed company bypasses Discovery pre-screen and enters heavy Research.
5. Heavy Research is adaptive by company/business model/sector.
6. Deep Dive cannot start before execution-layer input sufficiency passes.
7. Initial/full-refresh required DD input blocks must all be sufficient.
8. Targeted refresh requires reopened blocks and material downstream dependencies to be sufficient.
9. Sufficiency means mandatory coverage + evidence adequacy + no material blocking gap.
10. Research autonomously closes gaps until reasonably available sources are exhausted.
11. Material research hypotheses are formalized; tactical hypotheses may remain informal.
12. Same Research executor may determine `READY_FOR_DEEP_DIVE`.
13. Critical missing user input globally pauses Research.
14. User may resume by uploading the requested item and writing “voilà”.
15. One authoritative Evidence Ledger exists per run lineage/version, not competing primary/external authorities.
16. Deep Dive may continue targeted research and append to the authoritative ledger.
17. One Lead Analyst orchestrates specialist blocks.
18. Specialists access the full evidence corpus.
19. Specialists may research and add properly normalized evidence directly.
20. Specialist work may parallelize where dependencies permit.
21. Canonical Deep Dive dependency order remains frozen.
22. `PROVISIONALLY_STABLE` is allowed as execution metadata.
23. Execution `CONFIDENCE = HIGH / MEDIUM / LOW` is allowed but has no frozen scoring/certification authority.
24. Frozen Conflict / Calculation / Assumption semantics are preserved.
25. New evidence can reopen a previously sufficient or stable block.
26. Maximum three execution discussions per run: Research / Deep Dive / Integration.
27. `00 — PILOTAGE` is permanent orchestration, never analytical truth.
28. Inter-stage transfer is artifact-based, not summary-based.
29. Stage prompts use short bootstraps + versioned Stage Contracts.
30. Exact artifact retrieval is required.
31. Stage completion is commit-like and depends on persistence + registry reconciliation.
32. Research and Deep Dive produce short human summaries plus a fallback Pilotage handoff.
33. Refresh starts with “What changed?” then uses the frozen delta classifier.
34. Prior canonical research is reusable knowledge, not automatically current evidence.
35. Refresh scope is determined by analyst impact assessment within the frozen classifier.
36. Every successful refresh produces a new immutable canonical snapshot.
37. Main site shows latest canonical state; company detail may expose history.
38. One analytical GO authorizes workflow execution, not production publication.
39. Production publication requires separate `GO PUBLISH <COMPANY>`.
40. Stage Contracts require dedicated regression before freeze.

---

# 45. CURRENT STATUS

```text
DOCUMENT = OROTITAN_RESEARCH_EXECUTION_PROCESS_V1_FREEZE_V1.0
STATUS = FROZEN
FREEZE_VERSION = 1.0
FREEZE_DATE = 2026-09-12
METHODOLOGY_CHANGE = NO
FROZEN_ANALYTICAL_METHOD = UNCHANGED

FREEZE BASIS:
→ OROTITAN_RESEARCH_EXECUTION_PROCESS_V1_v0.2
→ TARGETED_REGRESSION_v0.2 = PASS
→ USER_APPROVAL = YES

NEXT:
→ BUILD + VALIDATE PILOTAGE ORCHESTRATION CONTRACT
→ BUILD + VALIDATE RESEARCH_STAGE_CONTRACT
→ BUILD + VALIDATE DEEP_DIVE_STAGE_CONTRACT
→ BUILD + VALIDATE INTEGRATION_STAGE_CONTRACT
```
