# OROTITAN_INTEGRATION_STAGE_CONTRACT_V1 — FREEZE V1.0

**Project:** OroTitan Equity Research  
**Contract type:** Company Integration Stage execution contract  
**Status:** FROZEN — V1.0  
**Depends on:** `OROTITAN_RESEARCH_EXECUTION_PROCESS_V1_FREEZE_V1.0`, `OROTITAN_PILOTAGE_ORCHESTRATION_CONTRACT_V1_FREEZE_V1.0`, `OROTITAN_RESEARCH_STAGE_CONTRACT_V1_FREEZE_V1.0`, `OROTITAN_DEEP_DIVE_STAGE_CONTRACT_V1_FREEZE_V1.0`  
**Projection authority:** `04_INTEGRATION_SPEC_V1_PATCHED`, `04_SCREENER_SCHEMA_V1_PATCHED`  
**Deterministic authority:** canonical I2 computation / contract-validation layer and locked execution patch V1.0.1  
**Admission authority:** canonical I3-B validated snapshot admission contract  
**Methodology change:** NO

---

# 0. PURPOSE

The Integration Stage converts a completed, integration-ready Deep Dive dossier into one canonical machine-readable snapshot candidate without changing the analysis.

Core rule:

```text
DEEP DIVE / CERTIFIED DOSSIER
= ANALYTICAL SOURCE OF TRUTH

INTEGRATION
= MAP + PROJECT + RECOMPUTE DETERMINISTIC OUTPUTS + VALIDATE + RECONCILE + PREPARE

INTEGRATION
≠ RESEARCH
≠ ANALYSIS
≠ RE-VALUATION
≠ SCORE JUDGMENT
≠ CERTIFICATION SUBSTITUTE
≠ METHODOLOGY REPAIR
```

Integration must preserve:

```text
Evidence → Calculation → Judgment → Narrative
```

and project only authorized canonical outputs into the frozen Phase-4 representation.

---

# 1. AUTHORITY HIERARCHY

Integration obeys, in this order:

```text
1. FROZEN ANALYTICAL METHODOLOGY
2. LOCKED INVESTMENT POLICY / EXECUTION PATCHES / I2 / I3-B
3. OROTITAN_RESEARCH_EXECUTION_PROCESS_V1_FREEZE_V1.0
4. 04_INTEGRATION_SPEC_V1_PATCHED
5. 04_SCREENER_SCHEMA_V1_PATCHED
6. OROTITAN_INTEGRATION_STAGE_CONTRACT_V1
7. RUN-SPECIFIC BOOTSTRAP
```

The Deep Dive artifacts are authoritative analytical inputs, but they do not outrank higher-order contracts.

If a lower layer conflicts with a higher layer:

```text
CONTRACT_DRIFT = DETECTED
→ PRE_FLIGHT = FAIL
→ STOP
→ REPORT EXACT CONFLICT
→ RETURN TO PILOTAGE
```

Integration may never change an analytical output merely to make a payload validate.

---

# 2. STAGE ADMISSION

Integration may begin only if authoritative persisted state shows:

```text
DEEP_DIVE_STAGE_STATUS = COMPLETE
READY_FOR_INTEGRATION = YES
REQUIRED DEEP DIVE ARTIFACTS = AVAILABLE
NO BLOCKING EXECUTION DEFECT
```

`READY_FOR_INTEGRATION = YES` is not a positive investment verdict.

Valid integration-ready analytical outcomes may include:

```text
OROTITAN_STATUS = NO
NEXT_ACTION = WAIT_FOR_PRICE
NEXT_ACTION = WAIT_FOR_EVIDENCE
NEXT_ACTION = REJECT
BUSINESS_RESEARCH_STATUS = CERTIFIED_WITH_LIMITATIONS
INVESTMENT_CONCLUSION_STATUS = INSUFFICIENT_DATA
```

when those are completed, frozen-method-compliant outcomes rather than unfinished work.

The following do not qualify:

```text
IDENTITY LOCK FAILURE
REQUIRED WORK NOT PERFORMED
UNRESOLVED CONTRACT VERSION MISMATCH
MATERIAL METHOD / BASIS DEFECT
PERSISTENCE FAILURE
READY_FOR_INTEGRATION = NO
```

A human summary never satisfies stage admission.

---

# 3. PRE-FLIGHT

Before projection work:

```text
1. Resolve RUN_ID.
2. Verify COMPANY / ISSUER / SECURITY identity.
3. Verify CANONICAL_MODE / RUN_TYPE.
4. Verify DATA_CUTOFF.
5. Load exact INTEGRATION_STAGE_CONTRACT version.
6. Load exact 04_INTEGRATION_SPEC_V1_PATCHED version.
7. Load exact 04_SCREENER_SCHEMA_V1_PATCHED version.
8. Load exact authorized I2 version.
9. Load exact authorized I3-B version.
10. Verify higher-authority process compatibility.
11. Retrieve exact Deep Dive artifacts by ARTIFACT_ID + VERSION + RUN_ID + STATUS.
12. Verify DEEP_DIVE_STAGE_STATUS = COMPLETE.
13. Verify READY_FOR_INTEGRATION = YES.
14. Resolve baseline canonical snapshot for REFRESH / ACTIVATION CHECK.
15. Verify current identity-registry records required for L1 projection.
16. Verify no artifact, cutoff, contract, method or version mismatch.
```

If any mandatory item fails:

```text
PRE_FLIGHT = FAIL
→ DO NOT BUILD SNAPSHOT
→ REPORT EXACT FAILURE
→ RETURN TO PILOTAGE
```

The bootstrap and human summaries are routing aids only.

---

# 4. REQUIRED INPUT ARTIFACTS

Integration resolves the exact authoritative Deep Dive artifacts required for the run scope.

Conceptually, these include:

```text
DEEP_DIVE_REPORT
UPDATED EVIDENCE_LEDGER VERSION / REFERENCES
CONFLICT_LEDGER VERSION / REFERENCES
CALCULATION_LEDGER
MATERIAL_ASSUMPTION_REGISTER
ANALYTICAL_BLOCK_OUTPUTS
CROSS_BLOCK_RECONCILIATION_RECORD
RED_TEAM_PREMORTEM_RECORD
VALUATION_ARTIFACT
CERTIFICATION_ARTIFACT
SCORING_INPUTS / OUTPUTS when permitted
OROTITAN_TERMINAL_GATE_ARTIFACT
READINESS_NEXT_ACTION_ARTIFACT
DEEP_DIVE_STAGE_MANIFEST
```

Integration must use exact artifact identities, not:

```text
filename guessing
"latest-looking" file
chat-memory reconstruction
human-summary reconstruction
```

---

# 5. PROJECTION BOUNDARY

The governing Phase-4 boundary is:

```text
CERTIFIED / PERMITTED DEEP DIVE DOSSIER
= SOURCE OF ANALYTICAL TRUTH

CANONICAL SNAPSHOT
= STRUCTURED PROJECTION
```

Integration may:

```text
MAP
NORMALIZE REPRESENTATION
RECOMPUTE FROZEN DETERMINISTIC OUTPUTS
VALIDATE
RECONCILE
REFERENCE SOURCE ARTIFACTS
PREPARE PUBLISHABLE SNAPSHOT
```

Integration may not:

```text
INVENT A NEW SCORE
CHANGE A DIMENSION JUDGMENT
CHANGE A MOAT / RUNWAY / RISK VERDICT
CHANGE VALUATION ASSUMPTIONS
CHANGE CERTIFICATION STATUS
OVERRIDE SCORE_PERMISSION
UPGRADE AN ELITE GATE
DOWNGRADE A BLOCK TO MAKE PAYLOAD FIT
CREATE MISSING ANALYTICAL EVIDENCE
SILENTLY DEFAULT UNKNOWN TO ZERO / NULL / EMPTY
```

If the Deep Dive output cannot be represented without semantic loss:

```text
INTEGRATION_CONFLICT = OPEN
→ DO NOT PATCH ANALYSIS IN INTEGRATION
→ RETURN TO APPROPRIATE UPSTREAM CONTRACT
```

---

# 6. TARGET CANONICAL OBJECT MODEL

The V1 projection uses:

```text
L1_IDENTITY
  issuer
  securities[]
  research_dossier

CURRENT_SNAPSHOT
HISTORICAL_SNAPSHOTS[]
CURRENT_MARKET_PRICE
ACTIVATION_EVENTS[]
```

Within each analytical snapshot:

```text
L2 = RESEARCH / FUNDAMENTALS / CERTIFICATION / BUSINESS QUALITY
L3 = INVESTMENT / VALUATION
L4 = TERMINAL / READINESS / NEXT ACTION
```

Integration must not collapse issuer, security and dossier identity into one record.

---

# 7. L1 IDENTITY FIREWALL

Integration must resolve and preserve:

```text
ISSUER_ID
SECURITY_ID
DOSSIER_ID
CANDIDATE_EPISODE
LEGAL_NAME
DISPLAY_NAME
TICKER
ISIN
EXCHANGE
COUNTRY
REPORTING_CURRENCY
TRADING_CURRENCY
PRIMARY_LISTING
LISTING_STATUS
```

Rules:

```text
ISSUER ≠ SECURITY
TICKER ≠ ISSUER IDENTITY
ONE ISSUER MAY HAVE MULTIPLE SECURITIES
```

No ticker-guess identity mutation is allowed.

A snapshot must reference the exact issuer/security analyzed by Deep Dive.

Identity mismatch:

```text
→ I3-B ADMISSION FAIL
→ READY_TO_PUBLISH = NO
```

---

# 8. POINT-IN-TIME AND VERSION FIREWALL

Every snapshot candidate must retain:

```text
DATA_CUTOFF
REFERENCE_PRICE
REFERENCE_PRICE_DATE
CALCULATION_DATE
LAST_FULL_RESEARCH_DATE
SCORE_DATE
REPORT_VERSION
METHOD_VERSION
CALCULATION_VERSION
EVIDENCE_LEDGER_VERSION
DISCOVERY_VERSION
MOAT_VERSION
RUNWAY_VERSION
ROIC_VERSION
FCF_VERSION
VALUATION_VERSION
CERTIFICATION_VERSION
```

Keep distinct:

```text
DATA_CUTOFF
REFERENCE_PRICE_DATE
CALCULATION_DATE
CURRENT MARKET PRICE DATE
```

A numeric research reference price requires a valid `REFERENCE_PRICE_DATE`.

Historical snapshots are immutable.

A new run creates a new snapshot/version. It never rewrites the prior snapshot.

---

# 9. RESEARCH REFERENCE PRICE VS CURRENT MARKET PRICE

Mandatory separation:

```text
RESEARCH_REFERENCE_PRICE
≠ CURRENT_MARKET_PRICE
```

`current_snapshot.data_lock.reference_price` is immutable within the snapshot.

`CURRENT_MARKET_PRICE` is refreshable market data outside the analytical snapshot.

A market-price update must not rewrite:

```text
DATA_CUTOFF
REFERENCE_PRICE
REFERENCE_PRICE_DATE
OQS
historical analytical judgments
```

A market-zone crossing may create an activation event, but:

```text
MARKET EVENT
≠ CERTIFIED SNAPSHOT
```

and can never directly create a `BUY` state because no such canonical state exists.

---

# 10. SPECIAL-STATE SEMANTICS

Canonical semantic states are explicit:

```text
UNKNOWN
NOT_APPLICABLE
NOT_ASSESSABLE
MISSING
NOT_AVAILABLE
```

Rules:

```text
UNKNOWN ≠ 0
NOT_APPLICABLE ≠ 0
NOT_ASSESSABLE ≠ null
MISSING ≠ empty string
NOT_AVAILABLE ≠ false
```

Optional whole objects may be omitted where the schema permits.

A schema-required analytical field must use the exact state supported by the analytical dossier.

Integration may not invent a semantic state merely to satisfy validation.

If the source dossier does not establish which state is correct:

```text
SEMANTIC_MAPPING = UNRESOLVED
→ BLOCK
→ RETURN UPSTREAM
```

---

# 11. MAPPING DISCIPLINE

Every projected field must have one of these origins:

```text
A. STORED / TRACEABLE JUDGMENT
B. STORED CALCULATION OUTPUT
C. STORED POLICY INPUT
D. DETERMINISTICALLY RECOMPUTABLE OUTPUT
E. OPERATIONAL / IDENTITY STATE
F. TRACEABILITY REFERENCE
```

For each material mapped field Integration should retain, in an internal mapping record:

```text
TARGET_FIELD
SOURCE_ARTIFACT_ID
SOURCE_PATH / SOURCE_FIELD
SOURCE_TYPE
TRANSFORMATION
DETERMINISTIC_RECOMPUTE = YES / NO
SPECIAL_STATE if applicable
VALIDATION_STATUS
```

No analytical field may derive from free-form narrative if an authoritative structured output exists.

---

# 12. STORED JUDGMENTS VS DETERMINISTIC OUTPUTS

Stored / traceable judgments include, as applicable:

```text
fundamental states
dimension judgments
certification statuses
hard blockers
material limitations
critical unknowns
unresolved conflicts
MOS
valuation reliability
market expectation gap
Elite gate judgments
readiness
opportunity path
next action
refresh class
thesis invalidation triggers
```

Deterministically recomputable outputs include:

```text
OQS_RAW
WEAK_LINK_CAP
OQS
QUALITY_CLASS when numeric
OVS
INVESTMENT_RAW
INVESTMENT_SCORE
INVESTMENT_CLASS when numeric
OROTITAN_STATUS
POTENTIAL_OROTITAN_MAX_PRICE when all required components exist
```

Integration must not trust a hand-entered deterministic result merely because it appears in a report.

The canonical server-side deterministic layer is authoritative.

---

# 13. I2 RECOMPUTATION

Integration must run the authorized I2 deterministic computation over the canonical judgment / valuation inputs.

Required deterministic checks include:

```text
OQS_RAW
WEAK_LINK_CAP
OQS
QUALITY_CLASS
OVS
INVESTMENT_RAW
INVESTMENT_SCORE
INVESTMENT_CLASS
OROTITAN_STATUS
POTENTIAL_OROTITAN_MAX_PRICE when applicable
```

The frozen formulas, anchors, caps and state rules may not be modified here.

No frontend arithmetic is authoritative.

---

# 14. N-SELECTION PATCH V1.0.1

For OVS normalization input `N`:

```text
IF MATURE_NORMALIZATION_RETURN
   is valid + numeric + reconciled + certifiable
→ N = MATURE_NORMALIZATION_RETURN

ELSE IF MATURE_NORMALIZATION_RETURN
        is legitimately non-numeric because
        NOT_ASSESSABLE / NOT_AVAILABLE after required work
        AND NO_MULTIPLE_EXPANSION_RETURN is valid + numeric + interpretable
→ N = NO_MULTIPLE_EXPANSION_RETURN

ELSE IF MATURE_NORMALIZATION_RETURN
        exists but is invalid / unreconciled
→ FAIL CLOSED
→ DO NOT FALL BACK AROUND THE FAILURE
```

When both returns are valid numeric:

```text
MATURE NORMALIZATION WINS
```

regardless of whether it is numerically higher or lower.

Integration must verify that I2 applies this exact selector.

---

# 15. I2 RECONCILIATION

After deterministic recomputation compare the canonical computed result with Deep Dive’s persisted deterministic outputs.

Use:

```text
I2_RECONCILIATION
= PASS | FAIL | NOT_APPLICABLE
```

`PASS` requires semantic and numerical consistency at the canonical computation precision.

A mismatch is not repaired by overwriting the dossier silently.

Instead:

```text
I2_RECONCILIATION = FAIL
→ IDENTIFY FIELD / INPUT / VERSION CAUSE
→ READY_TO_PUBLISH = NO
→ RETURN TO DEEP DIVE OR COMPUTATION CONTRACT AS APPROPRIATE
```

If the discrepancy is only display rounding, preserve the canonical raw result and approved display rounding without treating it as an analytical conflict.

---

# 16. SCORE_PERMISSION FIREWALL

Canonical rules must be enforced structurally.

If:

```text
SCORE_PERMISSION = SUSPENDED
```

then:

```text
OQS_RAW = NOT_AVAILABLE
WEAK_LINK_CAP = NOT_AVAILABLE
OQS = NOT_AVAILABLE
QUALITY_CLASS = NOT_AVAILABLE
INVESTMENT_RAW = NOT_AVAILABLE
INVESTMENT_SCORE = NOT_AVAILABLE
INVESTMENT_CLASS = NOT_AVAILABLE
```

For OVS:

```text
SCORE_PERMISSION = SUSPENDED
AND VALUATION_RELIABILITY = HIGH | MEDIUM | LOW
→ OVS = NOT_AVAILABLE

SCORE_PERMISSION = SUSPENDED
AND VALUATION_RELIABILITY = NOT_ASSESSABLE
→ OVS = NOT_ASSESSABLE
```

If:

```text
BUSINESS_RESEARCH_STATUS = NOT_CERTIFIED
```

numeric OQS is prohibited.

If valuation is not certifiable / assessable, numeric OVS and Investment Score are prohibited under the frozen rules.

No score-with-an-asterisk workaround exists.

---

# 17. BUSINESS QUALITY PROJECTION

Project the seven canonical dimensions only:

```text
MOAT
RUNWAY
RETURN_QUALITY
CASH_ECONOMICS
CAPITAL_ALLOCATION
MANAGEMENT_GOVERNANCE
RESILIENCE_RISK
```

Dimension judgment precision remains 5-point increments where numeric.

Integration must preserve evidence references by dimension.

Prohibited:

```text
MARGIN SCORE
PRICING SCORE
GROWTH SCORE
RECURRING REVENUE SCORE
BALANCE SHEET SCORE
OROTITAN PROXIMITY SCORE
```

No additional scoring dimension may be introduced.

---

# 18. VALUATION PROJECTION

The snapshot must preserve, as applicable:

```text
PRIMARY_EXPECTED_RETURN
RETURN_HORIZON
NO_MULTIPLE_EXPANSION_RETURN
MATURE_NORMALIZATION_RETURN
MARGIN_OF_SAFETY
VALUATION_RELIABILITY
MARKET_EXPECTATION_GAP
OVS
PRICE_LADDER
```

Price Ladder must retain:

```text
VALUATION_DATE
DATA_CUTOFF
REFERENCE_PRICE
CURRENCY
REQUIRED_RETURN_H
STRONG_RETURN_THRESHOLD
EXCEPTIONAL_RETURN_THRESHOLD
PRICE_FOR_REQUIRED_RETURN_H
PRICE_FOR_STRONG_RETURN
PRICE_FOR_EXCEPTIONAL_RETURN
INVESTABLE_PRICE_ZONE
STRONG_OPPORTUNITY_ZONE
POTENTIAL_OROTITAN_PRICE_ZONE
POTENTIAL_OROTITAN_MAX_PRICE
POTENTIAL_OROTITAN_COMPONENTS
ASSUMPTIONS / VERSION
METHOD_VERSION
CALCULATION_VERSION
```

The current locked policy is inherited by version:

```text
REQUIRED_RETURN_H = 10.0% p.a.
STRONG_RETURN_THRESHOLD = 12.5% p.a.
EXCEPTIONAL_RETURN_THRESHOLD = 15.0% p.a.
```

Integration does not reselect valuation assumptions.

---

# 19. OROTITAN TERMINAL PROJECTION

The schema requires exactly ten terminal gate records:

```text
CERTIFICATION_GATE
MOAT_ELITE
RUNWAY_ELITE
RETURN_QUALITY_ELITE
CASH_ECONOMICS_ELITE
CAPITAL_ALLOCATION_ELITE
MANAGEMENT_GOVERNANCE_ELITE
RESILIENCE_ELITE
MATERIAL_WEAK_LINK_GATE
VALUATION_ELITE
```

Each gate carries:

```text
STATE = PASS | FAIL | NOT_ASSESSABLE
RATIONALE
EVIDENCE_IDS[]
```

`OROTITAN_STATUS = YES` is valid only when every frozen conjunctive requirement passes.

Integration recomputes the terminal status deterministically from the gate states and required certification / valuation states.

High score alone never changes the result.

---

# 20. POTENTIAL OROTITAN PRICE ZONE

`POTENTIAL_OROTITAN_PRICE_ZONE` may be populated only when every required non-valuation gate is already satisfied under the frozen method.

Otherwise:

```text
POTENTIAL_OROTITAN_PRICE_ZONE = NOT_AVAILABLE
POTENTIAL_OROTITAN_MAX_PRICE = NOT_AVAILABLE
```

When all four components are valid and available:

```text
POTENTIAL_OROTITAN_MAX_PRICE
= deterministic minimum of authorized components
```

according to the canonical I2 contract.

Integration may not construct a potential zone to imply proximity where non-valuation gates fail.

---

# 21. READINESS / OPPORTUNITY / NEXT ACTION

Preserve exactly:

```text
DOSSIER_READINESS
= READY | PARTIALLY_READY | NOT_READY

OPPORTUNITY_PATH
= DIRECT | PREPARED

NEXT_ACTION
= INVESTABLE_NOW
| WAIT_FOR_PRICE
| WAIT_FOR_EVIDENCE
| REFRESH_REQUIRED
| REJECT
```

No readiness score exists.

`READY` is operational readiness, not business quality.

The canonical schema must reject `READY` when incompatible blockers / critical unknowns / stale or absent required operational elements remain.

---

# 22. REFRESH CLASS

Preserve:

```text
PRICE_ONLY_DELTA
ROUTINE_FUNDAMENTAL_DELTA
FULL_REFRESH_REQUIRED
```

The Integration Stage does not reclassify a refresh based on intuition.

It consumes the authorized classifier from upstream and validates the resulting transition.

---

# 23. PRICE_ONLY_DELTA TRANSITION INVARIANT

For:

```text
REFRESH_CLASS = PRICE_ONLY_DELTA
```

and no fundamental change:

```text
OQS_NEW = OQS_PREVIOUS
```

Fundamental quality judgments must remain unchanged unless the authorized upstream process explicitly reopened them.

Valuation-dependent outputs may change:

```text
PRIMARY_EXPECTED_RETURN
OVS
INVESTMENT_SCORE
PRICE_LADDER
NEXT_ACTION
OROTITAN VALUATION GATE / STATUS where affected by price
```

A price move may not silently rewrite business quality.

---

# 24. ROUTINE FUNDAMENTAL REFRESH TRANSITION

For:

```text
ROUTINE_FUNDAMENTAL_DELTA
```

Integration must verify:

```text
ONLY AUTHORIZED REOPENED BLOCKS
+
MATERIAL DOWNSTREAM DEPENDENCIES
```

changed analytically, unless the Deep Dive documents a broader justified reopening.

The old snapshot remains unchanged.

The new snapshot carries the new run’s complete canonical state after downstream reconciliation and recertification.

---

# 25. FULL REFRESH TRANSITION

For:

```text
FULL_REFRESH_REQUIRED
```

Integration requires a fully re-established current dossier consistent with the full affected Deep Dive chain.

Prior canonical state may inform traceability but may not be copied forward as unverified truth.

The result is a new immutable global snapshot.

---

# 26. ACTIVATION CHECK

For:

```text
CANONICAL_MODE = ACTIVATION CHECK
```

Integration must distinguish:

```text
ACTIVATION EVENT
≠ ANALYTICAL SNAPSHOT
```

If the Activation Check legitimately produces a new canonical analytical state, create a new snapshot candidate under the authorized mode.

If only a market-zone event occurred and no new certified analytical snapshot exists, record the event in the activation-event channel and do not fabricate a research snapshot.

A zone crossing never equals `INVESTABLE_NOW` automatically.

---

# 27. TRACEABILITY CONTRACT

Every snapshot carries:

```text
REPORT_ID
EVIDENCE_IDS[]
CALCULATION_IDS[]
```

Granular dimension / gate objects may carry narrower evidence references.

Integration does not duplicate the full Evidence Ledger inside the Screener payload.

Underlying proof remains authoritative in the report / evidence / calculation stores.

Rules:

```text
SNAPSHOT REFERENCE
→ RESOLVABLE TO ARTIFACT
→ RESOLVABLE TO ROOT SOURCE / CALCULATION INPUTS
```

Broken material traceability:

```text
→ I3-B ADMISSION FAIL
```

---

# 28. HISTORY / IMMUTABILITY

History is append-only.

Correct transition:

```text
OLD CURRENT SNAPSHOT
→ remains immutable historical snapshot

NEW VALIDATED SNAPSHOT
→ prepared as new candidate

AFTER AUTHORIZED PUBLICATION
→ research_dossier.current_snapshot_id points to NEW snapshot
```

Forbidden:

```text
UPDATE old analytical snapshot in place
DELETE old snapshot to simplify history
rewrite old DATA_CUTOFF
replace old reference price with current market price
```

A restatement or refresh creates a new version.

---

# 29. CURRENT SNAPSHOT POINTER BOUNDARY

Integration preparation does not itself authorize changing the production canonical pointer.

Before `GO PUBLISH`:

```text
CURRENT PRODUCTION SNAPSHOT
= UNCHANGED
```

Integration may prepare and validate a publishable snapshot candidate.

The physical implementation may stage candidate bytes/metadata if the authorized writer supports it, but it must not present the candidate as current canonical production state.

Only the publication workflow after explicit:

```text
GO PUBLISH <COMPANY>
```

may promote the new snapshot / pointer.

---

# 30. I3-B ADMISSION

I3-B is an admission gate, not economic authority.

Integration must submit or pre-validate the candidate against the exact I3-B contract.

Required checks include, as applicable:

```text
SCHEMA VALIDATION
PERSISTENCE BOUNDARY CHECKS
I2 RECONCILIATION
ATOMIC PERSISTENCE PRECONDITIONS
IDENTITY / RUN / VERSION CONSISTENCY
PIT / HISTORY INVARIANTS
TRACEABILITY RESOLUTION
```

Use:

```text
I3B_ADMISSION
= PASS | FAIL
```

If `FAIL`:

```text
READY_TO_PUBLISH = NO
```

Integration may not override I3-B.

---

# 31. SCHEMA VALIDATION

Validate the candidate against the exact pinned:

```text
04_SCREENER_SCHEMA_V1_PATCHED
schema_version = 1.0.0
```

unless an explicitly migrated run pins another compatible version.

Use:

```text
SCHEMA_VALIDATION = PASS | FAIL
```

Validation includes structural and logical state compatibility.

Cross-field arithmetic that JSON Schema cannot express is validated by I2 / contract validation.

A structurally valid payload with incorrect arithmetic is still invalid overall.

---

# 32. TRANSITION VALIDATION

For REFRESH / ACTIVATION transitions, validate against the prior canonical snapshot where required.

At minimum:

```text
prior snapshot immutable
new snapshot id distinct
issuer/dossier continuity valid
security transition intentional
DATA_CUTOFF progression valid
PRICE_ONLY_DELTA preserves OQS when fundamentals unchanged
current market price does not overwrite research reference price
historical special states preserved
```

Use:

```text
HISTORY_TRANSITION_VALIDATION
= PASS | FAIL | NOT_APPLICABLE
```

---

# 33. LEGACY DATA FIREWALL

Legacy Screener fields are not canonical analytical authority.

Integration must not source new canonical judgments from:

```text
legacy orotitan_score
legacy quality_orotitan
legacy status taxonomy
legacy O85/O90/O92/O95 entry zones
free score_components JSON
generic SQL NULL semantics
```

unless an explicit, source-supported canonical migration mapping exists.

Historical legacy records may remain historical.

Do not manufacture canonical evidence from legacy outputs.

---

# 34. ANALYTICAL DEFECT ROUTING

If Integration discovers:

```text
missing analytical field
wrong analytical state
unsupported dimension judgment
valuation inconsistency
certification contradiction
terminal-gate contradiction
evidence/calculation traceability defect
```

it must classify the defect:

```text
ANALYTICAL DEFECT
→ RETURN TO DEEP DIVE

RESEARCH EVIDENCE DEFECT
→ RETURN TO RESEARCH / DEEP DIVE RESEARCH LOOP

DETERMINISTIC COMPUTATION DEFECT
→ RETURN TO I2 / CONTRACT IMPLEMENTATION

SCHEMA / PROJECTION DEFECT
→ FIX IN INTEGRATION IMPLEMENTATION IF METHODOLOGY-PRESERVING

PERSISTENCE DEFECT
→ FIX I3-B / STORAGE PATH
```

Integration may not conceal category boundaries.

---

# 35. CANONICAL SNAPSHOT BUILD

The build sequence is:

```text
1. RESOLVE L1 IDENTITY
2. RESOLVE DEEP DIVE OUTPUTS
3. MAP STORED JUDGMENTS
4. MAP STORED CALCULATION OUTPUTS
5. MAP POLICY / VERSION INPUTS
6. MAP TRACEABILITY REFERENCES
7. APPLY EXPLICIT SPECIAL STATES
8. RUN I2 DETERMINISTIC COMPUTATION
9. INSERT RECOMPUTED DETERMINISTIC OUTPUTS
10. BUILD L2 / L3 / L4
11. BUILD DATA_LOCK / VERSIONS
12. BUILD SNAPSHOT CANDIDATE
13. SCHEMA VALIDATE
14. I2 RECONCILE
15. HISTORY TRANSITION VALIDATE
16. I3-B ADMISSION VALIDATE
17. BUILD PRE-PUBLICATION CONTROL CARD
18. DECLARE READY_TO_PUBLISH
19. STOP BEFORE PRODUCTION PROMOTION
```

This order is an execution sequence, not a new analytical methodology.

---

# 36. REQUIRED INTEGRATION ARTIFACTS

Persist / version at minimum conceptually:

```text
1. CANONICAL_SNAPSHOT_CANDIDATE
2. INTEGRATION_MAPPING_RECORD
3. SCHEMA_VALIDATION_REPORT
4. I2_RECONCILIATION_REPORT
5. HISTORY_TRANSITION_VALIDATION_REPORT
6. I3B_ADMISSION_REPORT
7. PRE_PUBLICATION_CONTROL_CARD
8. INTEGRATION_STAGE_MANIFEST
```

Exact physical filenames are implementation details.

No duplicate analytical ledger semantics are introduced.

---

# 37. PRE-PUBLICATION CONTROL CARD

Before publication show a concise user-facing card containing, as applicable:

```text
COMPANY
SECURITY
RUN_ID
DATA_CUTOFF
REFERENCE_PRICE / DATE

BUSINESS_RESEARCH_STATUS
INVESTMENT_CONCLUSION_STATUS
SCORE_PERMISSION

OQS
OVS
INVESTMENT_SCORE
OROTITAN_STATUS

PRIMARY_EXPECTED_RETURN
MARGIN_OF_SAFETY
VALUATION_RELIABILITY
NEXT_ACTION

SCHEMA_VALIDATION
I2_RECONCILIATION
HISTORY_TRANSITION_VALIDATION
I3B_ADMISSION

SNAPSHOT_CANDIDATE_ID
READY_TO_PUBLISH = YES | NO
```

Unavailable fields must use canonical semantic states, not invented zeros.

The card is a human checkpoint, not analytical authority.

---

# 38. READY_TO_PUBLISH

`READY_TO_PUBLISH = YES` only if:

```text
PRE_FLIGHT = PASS
DEEP_DIVE_STAGE_STATUS = COMPLETE
READY_FOR_INTEGRATION = YES
MAPPING = COMPLETE
SEMANTIC-STATE INTEGRITY = PASS
SCHEMA_VALIDATION = PASS
I2_RECONCILIATION = PASS
HISTORY_TRANSITION_VALIDATION = PASS or NOT_APPLICABLE
I3B_ADMISSION = PASS
TRACEABILITY = PASS
NO OPEN INTEGRATION BLOCKER
SNAPSHOT CANDIDATE PERSISTED / VERSIONED AS REQUIRED BY STAGE ARTIFACT MODEL
REGISTRY RECONCILED
```

It does not require:

```text
OROTITAN_STATUS = YES
NEXT_ACTION = INVESTABLE_NOW
OQS numeric
OVS numeric
INVESTMENT_SCORE numeric
CERTIFIED without limitations
```

because honest canonical non-numeric or negative states are valid.

---

# 39. PUBLICATION AUTHORIZATION FIREWALL

Integration must stop before production promotion.

Only:

```text
GO PUBLISH <COMPANY>
```

authorizes the publication mechanism.

Before publication, Pilotage / publisher re-verifies:

```text
RUN_ID
INTEGRATION_STAGE_STATUS = COMPLETE
READY_TO_PUBLISH = YES
SNAPSHOT_CANDIDATE_ID / VERSION
SCHEMA_VALIDATION = PASS
I2_RECONCILIATION = PASS
I3B_ADMISSION = PASS
NO PUBLICATION BLOCKER
```

Without GO:

```text
NO current_snapshot pointer mutation
NO production canonical promotion
NO site-current-state replacement
```

---

# 40. PUBLICATION TRANSACTION EXPECTATION

The authorized publication mechanism must preserve atomicity consistent with I3-B.

Conceptually:

```text
VALIDATED CANDIDATE
→ ATOMIC CANONICAL PERSISTENCE / PROMOTION
→ CURRENT SNAPSHOT POINTER UPDATE
→ PRIOR SNAPSHOT REMAINS IMMUTABLE
→ REGISTRY RECONCILIATION
```

If any required publication step fails:

```text
PUBLICATION = FAIL
→ DO NOT REPRESENT NEW SNAPSHOT AS CURRENT
→ REPORT RETRYABLE FAILURE
```

The exact transaction implementation is an engineering concern governed by I3-B.

---

# 41. CURRENT MARKET PRICE / ACTIVATION AFTER PUBLICATION

Market-price refresh remains outside the immutable analytical snapshot.

After publication:

```text
CURRENT_MARKET_PRICE may update independently
```

Zone crossings may append:

```text
ACTIVATION_EVENTS[]
```

An activation event must explicitly remain non-certified analytical state.

It can trigger a future Activation Check, not rewrite the published snapshot.

---

# 42. INTEGRATION STAGE STATUS

Use execution status such as:

```text
NOT_STARTED
IN_PROGRESS
BLOCKED
COMPLETE
```

The exact operational persistence vocabulary may follow the run registry implementation.

`COMPLETE` is permitted only after the commit-like finalization rule below.

---

# 43. SELF-AUDIT BEFORE COMPLETION

Integration must ask:

```text
Did we resolve the exact run / issuer / security?
Did we load exact authoritative Deep Dive artifacts?
Did we preserve DATA_CUTOFF and reference-price integrity?
Did we keep current market price outside the research snapshot?
Did we preserve explicit UNKNOWN / N/A / NOT_ASSESSABLE / MISSING / NOT_AVAILABLE semantics?
Did every material field map to an authoritative source?
Did we avoid deriving canonical judgments from narrative summaries?
Did we avoid legacy score/status contamination?
Did we run the exact pinned I2 computation?
Did the N selector follow Mature-first / legitimate-fallback / fail-closed?
Did deterministic outputs reconcile?
Did SCORE_PERMISSION suppress numeric outputs correctly?
Did terminal OroTitan use the exact ten gates?
Did we preserve the potential OroTitan zone firewall?
Did refresh transition invariants pass?
Did we preserve old snapshot immutability?
Did traceability references resolve?
Did schema validation pass?
Did I3-B admission pass?
Did we avoid repairing analytical defects inside Integration?
Did we avoid production promotion without GO PUBLISH?
```

Any material `NO` prevents normal completion.

---

# 44. STAGE FINALIZATION

Integration may be `COMPLETE` only after:

```text
1. REQUIRED INTEGRATION WORK COMPLETE
2. SELF-AUDIT COMPLETE
3. CANONICAL SNAPSHOT CANDIDATE GENERATED
4. INTEGRATION ARTIFACTS PERSISTED / VERSIONED
5. SCHEMA VALIDATION COMPLETE
6. I2 RECONCILIATION COMPLETE
7. HISTORY TRANSITION VALIDATION COMPLETE
8. I3-B ADMISSION COMPLETE
9. REGISTRY RECONCILED
10. INTEGRATION_STAGE_STATUS UPDATED
11. READY_TO_PUBLISH DECLARED
12. PRE-PUBLICATION CONTROL CARD PRODUCED
13. PILOTAGE HANDOFF PRODUCED
14. STOP BEFORE PRODUCTION PROMOTION
```

If persistence or registry reconciliation fails:

```text
INTEGRATION_STAGE_STATUS != COMPLETE
READY_TO_PUBLISH = NO
```

A valid-looking JSON answer alone never completes Integration.

---

# 45. PILOTAGE HANDOFF

Emit compact fallback routing metadata:

```text
COMPANY
RUN_ID
STAGE = INTEGRATION
INTEGRATION_STAGE_STATUS
DATA_CUTOFF
SNAPSHOT_CANDIDATE_ID / VERSION
SCHEMA_VALIDATION
I2_RECONCILIATION
HISTORY_TRANSITION_VALIDATION
I3B_ADMISSION
READY_TO_PUBLISH
CRITICAL_BLOCKERS
NEXT_REQUIRED_USER_ACTION
```

Normal path:

```text
Pilotage retrieves authoritative registry state directly.
```

Fallback handoff is routing metadata only.

---

# 46. FAIL-CLOSED RULES

At minimum:

```text
RUN / COMPANY / SECURITY MISMATCH
→ STOP

CONTRACT / SCHEMA / I2 / I3-B VERSION MISMATCH
→ STOP

DEEP DIVE ARTIFACT ID / VERSION / STATUS MISMATCH
→ STOP

READY_FOR_INTEGRATION != YES
→ NO INTEGRATION

DATA_CUTOFF / REFERENCE PRICE INTEGRITY FAILURE
→ BLOCK

AMBIGUOUS SPECIAL STATE
→ BLOCK / RETURN UPSTREAM

SCHEMA VALIDATION FAIL
→ READY_TO_PUBLISH = NO

I2 RECONCILIATION FAIL
→ READY_TO_PUBLISH = NO

INVALID / UNRECONCILED MATURE NORMALIZATION
→ FAIL CLOSED
→ NO SAME-MULTIPLE FALLBACK

SCORE_PERMISSION VIOLATION
→ INVALID SNAPSHOT

TERMINAL GATE INCONSISTENCY
→ INVALID SNAPSHOT

PRICE_ONLY_DELTA CHANGES OQS WITHOUT AUTHORIZED FUNDAMENTAL CHANGE
→ TRANSITION FAIL

HISTORY MUTATION
→ FAIL

TRACEABILITY FAILURE
→ I3-B FAIL

I3-B ADMISSION FAIL
→ READY_TO_PUBLISH = NO

NO GO PUBLISH
→ NO PRODUCTION PROMOTION
```

Unknowns remain unknown.

---

# 47. ACCEPTANCE TESTS REQUIRED BEFORE FREEZE

Validate at minimum:

```text
I01 Initial ANALYZE, fully certified, numeric scores
I02 Initial ANALYZE, OROTITAN_STATUS = NO
I03 Certified business, valuation NOT_ASSESSABLE
I04 SCORE_PERMISSION = SUSPENDED + valuation HIGH
I05 SCORE_PERMISSION = SUSPENDED + valuation NOT_ASSESSABLE
I06 BUSINESS_RESEARCH_STATUS = NOT_CERTIFIED
I07 CERTIFIED_WITH_LIMITATIONS valid projection
I08 INVESTMENT_CONCLUSION_STATUS = INSUFFICIENT_DATA after adequate work
I09 Exact issuer / security mismatch
I10 Deep Dive artifact version mismatch
I11 Contract version mismatch
I12 DATA_CUTOFF mismatch
I13 Numeric reference price without reference-price date
I14 UNKNOWN incorrectly mapped to zero
I15 NOT_APPLICABLE industrial ROIC for bank + sector method APPLIED
I16 Marketplace ROIC NOT_INTERPRETABLE valid
I17 Mature numeric + Same-Multiple numeric → Mature selected
I18 Mature unavailable + Same-Multiple numeric → fallback
I19 Mature invalid + Same-Multiple numeric → fail closed
I20 I2 numeric mismatch vs Deep Dive
I21 OQS formula recomputation
I22 OVS cap / state recomputation
I23 Investment Score recomputation
I24 OROTITAN YES with one Elite FAIL → rejected
I25 Potential OroTitan zone with non-valuation gate fail → unavailable
I26 READY with critical unknown → rejected
I27 PRICE_ONLY_DELTA preserves OQS
I28 PRICE_ONLY_DELTA current market price does not rewrite research reference price
I29 ROUTINE_FUNDAMENTAL_DELTA creates new immutable snapshot
I30 FULL_REFRESH_REQUIRED creates new immutable global snapshot
I31 Activation event without certified analysis does not create snapshot
I32 Historical snapshot lacks DATA_CUTOFF → rejected
I33 Broken Evidence / Calculation reference → admission fail
I34 Human summary only → not accepted
I35 Legacy orotitan_score cannot populate canonical terminal status
I36 Valid snapshot + no GO PUBLISH → no production promotion
I37 GO PUBLISH requested but I3-B fail → blocked
I38 Integration discovers analytical contradiction → routes upstream
I39 Persistence / registry failure → stage not complete
I40 Complete valid candidate → READY_TO_PUBLISH = YES
```

Required invariants:

```text
NO METHODOLOGY DRIFT
NO ANALYTICAL REWRITE IN INTEGRATION
NO SUMMARY-AS-AUTHORITY
NO LEGACY-SEMANTIC CONTAMINATION
NO NULL/UNKNOWN COLLAPSE
NO FRONTEND SCORE AUTHORITY
DETERMINISTIC I2 OUTPUTS EXACT
I3-B FAIL-CLOSED
IMMUTABLE HISTORY
NO PRODUCTION PROMOTION WITHOUT GO PUBLISH
```

---

# 48. CURRENT STATUS

```text
DOCUMENT = OROTITAN_INTEGRATION_STAGE_CONTRACT_V1_FREEZE_V1.0
STATUS = FROZEN
FREEZE_VERSION = 1.0
FREEZE_DATE = 2026-09-12
METHODOLOGY_CHANGE = NO

FREEZE BASIS:
→ CONTRACT v0.1
→ TARGETED_VALIDATION_v0.1 = PASS
→ 40 / 40 CONTRACT SCENARIOS = PASS
→ PHASE-4 NON-REGRESSION = PASS
→ USER CONTINUATION APPROVAL = YES

NEXT:
→ RUN CROSS-CONTRACT ORCHESTRATION VALIDATION
→ DESIGN PERSISTENT RUN / ARTIFACT REGISTRY
→ IMPLEMENT LIVE ORCHESTRATION WITHOUT PRODUCTION MUTATION
```
