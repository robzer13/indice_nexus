# OROTITAN_DEEP_DIVE_STAGE_CONTRACT_V1 — FREEZE V1.0

**Project:** OroTitan Equity Research  
**Contract type:** Company Deep Dive Stage execution contract  
**Status:** FROZEN — V1.0  
**Depends on:** `OROTITAN_RESEARCH_EXECUTION_PROCESS_V1_FREEZE_V1.0`, `OROTITAN_PILOTAGE_ORCHESTRATION_CONTRACT_V1_FREEZE_V1.0`, `OROTITAN_RESEARCH_STAGE_CONTRACT_V1_FREEZE_V1.0`  
**Analytical authority:** `01_ANALYSIS_STANDARD_V1`, `02_OROTITAN_MASTER_PROMPT_V1_PATCHED`, locked investment-policy / execution patches, canonical I2/I3-B contracts  
**Methodology change:** NO

---

# 0. PURPOSE

The Deep Dive Stage converts an admitted evidence base into a fully traceable OroTitan analytical dossier.

It answers, in the frozen order:

```text
WHAT BUSINESS ARE WE ACTUALLY ANALYZING?
→ WHAT ARE ITS ECONOMIC CHARACTERISTICS?
→ IS THE MOAT PROVEN?
→ IS THERE A REALISTIC RUNWAY?
→ AT WHAT RETURNS IS CAPITAL EMPLOYED?
→ HOW MUCH ECONOMIC CASH IS ACTUALLY REALIZED?
→ HAS CAPITAL BEEN ALLOCATED WELL?
→ ARE MANAGEMENT / GOVERNANCE ALIGNED?
→ WHAT DOES THE OUTSIDE VIEW SAY?
→ WHAT CAN BREAK THE THESIS?
→ WHAT DOES THE RED TEAM INVALIDATE?
→ WHAT IS THE BUSINESS WORTH / EXPECTED RETURN?
→ IS THE RESEARCH CERTIFIABLE?
→ MAY IT BE SCORED?
→ DOES THE TERMINAL OROTITAN GATE PASS?
→ WHAT IS THE DOSSIER READINESS / NEXT ACTION?
```

Core rule:

```text
DEEP DIVE
= ANALYSIS + TARGETED RESEARCH + CALCULATION + JUDGMENT + VALUATION
  + CERTIFICATION + PERMITTED SCORING + TERMINAL GATE + READINESS

DEEP DIVE
≠ RESEARCH SUMMARY EXPANSION
≠ THESIS CONFIRMATION EXERCISE
≠ SCORE-FIRST ANALYSIS
≠ VALUATION-FIRST ANALYSIS
≠ CONVERSATIONAL MEMORY RECONSTRUCTION
```

The governing epistemic chain remains:

> **Evidence → Calculation → Judgment → Narrative**

---

# 1. AUTHORITY HIERARCHY

Deep Dive obeys, in order:

```text
1. FROZEN ANALYTICAL METHODOLOGY
2. LOCKED INVESTMENT POLICY / EXECUTION PATCHES / I2 / I3-B
3. OROTITAN_RESEARCH_EXECUTION_PROCESS_V1_FREEZE_V1.0
4. OROTITAN_DEEP_DIVE_STAGE_CONTRACT_V1
5. RUN-SPECIFIC BOOTSTRAP
```

Research artifacts are evidence inputs, not higher authority.

If a conflict exists:

```text
CONTRACT_DRIFT = DETECTED
→ PRE_FLIGHT = FAIL
→ STOP
→ REPORT EXACT CONFLICT
→ RETURN TO PILOTAGE
```

A lower-authority prompt may never alter a frozen state vocabulary, formula, gate, cap, weighting, certification rule or valuation convention.

---

# 2. STAGE ADMISSION

Deep Dive may begin only if authoritative persisted Research state shows:

```text
RESEARCH_STAGE_STATUS = COMPLETE
READY_FOR_DEEP_DIVE = YES
REQUIRED RESEARCH ARTIFACTS = AVAILABLE
NO BLOCKING RESEARCH CONDITION
```

For a targeted refresh, admission applies to the reopened required scope and material downstream dependencies.

For `PRICE_ONLY_DELTA` / `ACTIVATION CHECK`, the stage may enter a reduced path only when the frozen refresh / activation architecture authorizes it.

A human summary cannot satisfy admission.

---

# 3. PRE-FLIGHT

Before any analytical work:

```text
1. Resolve RUN_ID.
2. Verify COMPANY / ISSUER / SECURITY identity.
3. Verify CANONICAL_MODE / RUN_TYPE.
4. Verify DATA_CUTOFF.
5. Load exact DEEP_DIVE_STAGE_CONTRACT version.
6. Verify higher-authority process compatibility.
7. Resolve baseline canonical snapshot when REFRESH / ACTIVATION.
8. Retrieve exact Research artifacts by ARTIFACT_ID + VERSION + RUN_ID + STATUS.
9. Verify RESEARCH_STAGE_STATUS = COMPLETE where required.
10. Verify READY_FOR_DEEP_DIVE = YES for required scope.
11. Verify ANALYSIS_INPUT_LOCK / DD input sufficiency record.
12. Verify Evidence Ledger version and Conflict Ledger references.
13. Verify no artifact / contract / cutoff mismatch.
```

If any mandatory item fails:

```text
PRE_FLIGHT = FAIL
→ DO NOT ANALYZE
→ REPORT EXACT FAILURE
→ RETURN TO PILOTAGE
```

The bootstrap is routing metadata, never analytical evidence.

---

# 4. POINT-IN-TIME INTEGRITY

The Deep Dive inherits the run `DATA_CUTOFF`.

```text
SOURCE_DATE <= DATA_CUTOFF
```

for evidence used as knowledge available at cutoff.

Keep distinct:

```text
SOURCE_DATE
AS_OF_DATE / DATA_PERIOD
DATA_CUTOFF
REFERENCE_PRICE_DATE
CALCULATION_DATE
```

Post-cutoff evidence may not silently enter the current run.

If a material post-cutoff source is required:

```text
DO NOT ABSORB SILENTLY
→ STOP AFFECTED WORK
→ REQUIRE CONTROLLED NEW / REFRESH RUN OR EXPLICIT NEW CUTOFF
```

---

# 5. CANONICAL DEEP DIVE ORDER

The frozen dependency order is authoritative:

```text
0. IDENTITY / POINT-IN-TIME LOCK
1. EVIDENCE LEDGER
2. BUSINESS / SEGMENT / ECONOMIC MODEL
3. ECONOMIC QUALITY SYNTHESIS
4. MOAT PROOF
5. GROWTH / RUNWAY
6. RETURN ON CAPITAL / MARGINAL RETURN
7. FCF / OWNER EARNINGS / FORENSIC
8. CAPITAL ALLOCATION
9. MANAGEMENT / GOVERNANCE
10. OUTSIDE VIEW / BASE RATES
11. RISK / RESILIENCE
12. RED TEAM / PRE-MORTEM
13. VALUATION / EXPECTED RETURN
14. RESEARCH CERTIFICATION
15. SCORING
16. OROTITAN TERMINAL GATE
17. READINESS / NEXT ACTION
```

This is a dependency order, not necessarily a serial scheduling order.

Hard sequencing invariants:

```text
VALUATION FINALIZATION
cannot precede required fundamental inputs

CERTIFICATION
cannot precede required analytical work + valuation state

SCORING
cannot precede Certification score permission

OROTITAN TERMINAL GATE
cannot precede the required certification / scoring / valuation states
```

---

# 6. LEAD ANALYST ARCHITECTURE

One Lead Analyst owns dossier coherence.

```text
ONE LEAD ANALYST
+
SPECIALIST ANALYTICAL BLOCKS
```

Lead Analyst responsibilities:

```text
ORCHESTRATE BLOCKS
MANAGE DEPENDENCIES
CONTROL PARALLELIZATION
RECONCILE CONTRADICTIONS
CONTROL REOPENINGS
ENFORCE FROZEN METHODOLOGY
ENFORCE POINT-IN-TIME
RECONCILE ASSUMPTIONS / CALCULATIONS
RUN CROSS-BLOCK CONSISTENCY
OWN FINAL DOSSIER-LEVEL SYNTHESIS
```

The Lead Analyst may not override deterministic formulas or certification gates based on conviction.

---

# 7. SPECIALIST BLOCKS

Internal specialist roles may include:

```text
IDENTITY / DATA DEFINITIONS
BUSINESS MODEL / ECONOMIC QUALITY
MOAT
RUNWAY
RETURN QUALITY
FCF / FORENSIC
CAPITAL ALLOCATION
MANAGEMENT / GOVERNANCE
OUTSIDE VIEW / BASE RATES
RISK / RESILIENCE
RED TEAM / PRE-MORTEM
VALUATION
CERTIFICATION AUDIT
```

This specialization is internal to one Deep Dive discussion / run.

The user does not manage a separate chat for each block.

Every specialist has access to the full authoritative evidence corpus, but must avoid narrative contamination from other blocks.

---

# 8. SAFE PARALLELIZATION

Use:

```text
PARALLELIZE WHEN DEPENDENCIES ALLOW
DO NOT BYPASS ECONOMIC DEPENDENCIES
```

Safe examples may include:

```text
MOAT evidence testing
RUNWAY denominator reconstruction
MANAGEMENT / GOVERNANCE evidence review
OUTSIDE VIEW collection
RISK mapping
```

when their required upstream facts are available.

Unsafe examples include:

```text
FINAL VALUATION
before return / cash / runway assumptions stabilize

FINAL SCORING
before certification

TERMINAL OROTITAN GATE
before valuation and certification
```

Parallelization is an execution optimization only.

---

# 9. EXECUTION BLOCK LIFECYCLE

For execution management only:

```text
INSUFFICIENT
IN_PROGRESS
PROVISIONALLY_STABLE
LOCKED
```

These are not frozen analytical verdicts and not Certification states.

At Certification, the frozen block-execution vocabulary remains:

```text
COMPLETE
COMPLETE_WITH_LIMITATIONS
NOT_APPLICABLE
MISSING
```

## 9.1 `INSUFFICIENT`

Evidence / definitions are not adequate to continue the affected analytical work.

## 9.2 `IN_PROGRESS`

Analysis is active.

## 9.3 `PROVISIONALLY_STABLE`

The block may feed downstream work but remains reopenable.

It must expose material:

```text
MATERIAL_DEPENDENCIES[]
REOPEN_TRIGGERS[]
```

## 9.4 `LOCKED`

The block is finalized for the current run before Certification mapping.

```text
LOCKED ≠ CERTIFIED
```

---

# 10. EXECUTION CONFIDENCE

A block may carry:

```text
EXECUTION_CONFIDENCE = HIGH | MEDIUM | LOW
```

with concise rationale.

This is execution metadata only.

It must not replace or modify:

```text
EVIDENCE_GRADE
DATA_QUALITY
ATTRIBUTABILITY
INTERPRETABILITY
FORENSIC_RELIABILITY
VALUATION_RELIABILITY
CERTIFICATION STATUS
DIMENSION SCORE
ELITE GATE
```

No confidence sub-score is created.

---

# 11. STANDARD BLOCK EXECUTION ENVELOPE

Each analytical block should expose:

```text
BLOCK_ID
BLOCK_VERSION
EXECUTION_STATUS
EXECUTION_CONFIDENCE

CANONICAL_VERDICT_FIELDS[]
CORE_FINDINGS[]
SUPPORTING_EVIDENCE_IDS[]
CONTRADICTING_EVIDENCE_IDS[]
CALCULATION_IDS[]
MATERIAL_ASSUMPTION_IDS[]
CONFLICT_IDS[]
UNRESOLVED_POINTS[]

MATERIAL_DEPENDENCIES[]
REOPEN_TRIGGERS[]

RATIONALE
LAST_RESEARCH_DATE
DATA_CUTOFF
```

`CANONICAL_VERDICT_FIELDS[]` must use only the frozen analytical vocabulary.

---

# 12. EVIDENCE AUTHORITY DURING DEEP DIVE

The Deep Dive consumes and extends the same authoritative Evidence Ledger lineage created by Research.

```text
ONE AUTHORITATIVE EVIDENCE LEDGER
```

Do not create a second analytical evidence authority.

Every material conclusion must ultimately trace to:

```text
VERDICT CLAIM
→ JUDGMENT
→ EVIDENCE_ID and/or CALCULATION_ID
→ ROOT SOURCE
```

The executive narrative may not create a new fact, number or evidence state.

---

# 13. NEW RESEARCH DURING DEEP DIVE

Deep Dive is not restricted to the Research-stage corpus.

A specialist may perform new targeted research for:

```text
MATERIAL GAP
CONTRADICTION
COUNTERFACTUAL
NEGATIVE EVIDENCE
DEFINITION / BASIS QUESTION
NEW MATERIAL HYPOTHESIS
MISSING VALUATION INPUT
RISK / BASE-RATE QUESTION
```

Any material new source must be normalized into the authoritative Evidence Ledger before being relied upon materially.

Root-source, independence, claim-fit, freshness and conflict rules remain unchanged.

---

# 14. DYNAMIC SUFFICIENCY / RETURN TO RESEARCH

Research-stage admission is not permanent proof of sufficiency.

If Deep Dive discovers:

```text
MATERIAL GAP
MATERIAL UNRESOLVED CONFLICT
FAILED MATERIAL ASSUMPTION
HIDDEN CRITICAL QUESTION
DEFINITION / BASIS MISMATCH
FALSE SOURCE INDEPENDENCE
```

then the affected input scope may move:

```text
SUFFICIENT → INSUFFICIENT
```

and the analytical block:

```text
PROVISIONALLY_STABLE / LOCKED → REOPEN
```

The affected work must stop and enter a targeted evidence-repair loop.

Deep Dive may perform that targeted research inside the same discussion while preserving stage boundaries in the artifact model.

If a truly critical input remains inaccessible after reasonable retrieval attempts and it blocks a Core conclusion or downstream certification:

```text
DEEP_DIVE_STAGE_STATUS = PAUSED_CRITICAL_INPUT
→ GLOBAL PAUSE
→ PRECISE USER ASSISTANCE REQUEST
```

The request must state the exact missing item, why it is critical, searches attempted, acceptable substitute and blocked outputs.

---

# 15. INTER-BLOCK COMMUNICATION / CONTAMINATION FIREWALL

Specialists may consume:

```text
FACTS
CALCULATIONS
MATERIAL ASSUMPTIONS
STRUCTURED FINDINGS
PROVISIONAL CANONICAL VERDICT FIELDS
LIMITATIONS
EXECUTION STATUS
```

They may not treat as authority:

```text
GLOBAL CONVICTION LANGUAGE
PERSUASIVE NARRATIVE
EXPECTED SCORE
INVESTMENT CONCLUSION
"THIS IS A GREAT COMPANY"
```

The Lead Analyst owns cross-block synthesis.

No specialist should adjust a conclusion merely because another block is optimistic or pessimistic.

---

# 16. CONFLICT LEDGER

Preserve the frozen Conflict Ledger semantics.

```text
CONFLICT_ID
METRIC / CLAIM
SOURCE_A / VALUE_A / EVIDENCE_ID_A
SOURCE_B / VALUE_B / EVIDENCE_ID_B
CONFLICT_TYPE
REASON
RESOLUTION = RESOLVED | UNRESOLVED
MATERIALITY
AFFECTED_OUTPUTS[]
```

Rule:

```text
NEVER CHOOSE THE CONVENIENT NUMBER SILENTLY
```

A material unresolved conflict blocks the affected output / certification as required by the frozen method.

---

# 17. DATA-DEFINITION FIREWALL

Every critical metric must retain:

```text
METRIC_NAME
DEFINITION
PERIOD
CURRENCY
BASIS
ADJUSTMENTS
METHOD_VERSION
```

Preserve:

```text
REPORTED
≠ MANAGEMENT-ADJUSTED
≠ OROTITAN-NORMALIZED
```

Explicit bridges are required.

One label may not silently refer to multiple economic definitions.

---

# 18. CALCULATION LEDGER

Every material calculation retains:

```text
CALCULATION_ID
METRIC_NAME
FORMULA
INPUTS[]
INPUT_EVIDENCE_IDS[]
UNITS
CURRENCY
PERIOD
BASIS
RAW_RESULT
ROUNDING_RULE
PUBLISHED_RESULT
METHOD_VERSION
CALCULATION_VERSION
AUTOMATED_CHECK_STATUS
LIMITATIONS
```

Material calculations must be independently reproducible.

The analyst may define economically appropriate inputs and assumptions; deterministic arithmetic may not be overridden by conviction.

---

# 19. MATERIAL ASSUMPTION DISCIPLINE

Each material assumption retains:

```text
ASSUMPTION_ID
VARIABLE
VALUE / RANGE
EPISTEMIC_TYPE
SOURCE / RATIONALE
SENSITIVITY
USED_IN
```

Assumption leakage into factual narrative is prohibited.

A material assumption must remain distinguishable from reported, calculated, consensus and estimated facts.

---

# 20. IDENTITY / POINT-IN-TIME LOCK

Before valuation, scoring or certification, lock:

```text
LEGAL_ENTITY
SECURITY / SHARE_CLASS
TICKER
EXCHANGE
REPORTING_CURRENCY
FISCAL_YEAR
DATA_CUTOFF
SOURCE_DATE
CALCULATION_DATE
REFERENCE_PRICE
REFERENCE_PRICE_DATE
ECONOMIC_SHARE_COUNT
MARKET_CAP
EV_BRIDGE
LATEST_AVAILABLE_FILING
```

Market cap:

```text
MARKET_CAP = REFERENCE_PRICE × ECONOMIC_SHARE_COUNT
```

Do not automatically use diluted EPS weighted-average shares for instantaneous market cap.

For ordinary non-financials, EV must reconcile economically consistent claims, debt-like items, excess cash and non-operating investments.

Identity lock failure is a Certification hard blocker.

---

# 21. BUSINESS / SEGMENT / ECONOMIC MODEL

Before judging quality, establish:

```text
WHO PAYS?
FOR WHAT?
WHY?
RECURRENCE?
PRICE DRIVER?
VOLUME DRIVER?
CAPITAL REQUIRED?
MATERIAL SEGMENTS?
GEOGRAPHIES?
ORGANIC VS ACQUIRED?
```

Minimum outputs:

```text
REVENUE_STREAMS[]
CUSTOMER_GROUPS[]
SEGMENTS[]
GEOGRAPHIES[]
PRICING_MECHANISMS[]
VOLUME_DRIVERS[]
RECURRENCE_CHARACTERISTICS[]
CAPITAL_REQUIREMENTS[]
KEY_COST_DRIVERS[]
```

No standalone score exists for this block.

---

# 22. ECONOMIC QUALITY SYNTHESIS

Summarize descriptively:

```text
pricing behavior
volume behavior
retention / recurrence where relevant
unit / segment economics
margin structure
capital intensity
working-capital structure
operating leverage
per-share economic direction
```

Preserve:

```text
HIGH MARGIN ≠ MOAT
HIGH RECURRING REVENUE ≠ SWITCHING COST
HIGH ROIC ≠ MOAT
LOW CAPITAL INTENSITY ≠ AUTOMATIC SUPERIOR QUALITY
```

This block is not an eighth score dimension.

---

# 23. MOAT PROOF BLOCK

Use the frozen causal chain:

```text
CLAIM / HYPOTHESIS
→ MECHANISM
→ EXTERNAL / BEHAVIORAL EVIDENCE
→ OBSERVED ECONOMIC CONSEQUENCE
→ COUNTERFACTUAL / REPLICATION / SUBSTITUTION
→ DYNAMIC EVIDENCE: TREND + ENTRY / EXIT
→ DURABILITY
```

Canonical states:

```text
MOAT_EVIDENCE_STATE
= UNKNOWN | PLAUSIBLE | SUPPORTED | STRONGLY_SUPPORTED | FALSIFIED

MOAT_TREND
= STRENGTHENING | STABLE | ERODING | UNCLEAR

MOAT_DURABILITY
= LIMITED | MODERATE | LONG | UNKNOWN
```

Rules:

```text
UNKNOWN ≠ FALSIFIED
issuer-only evidence ≠ normally STRONGLY_SUPPORTED
negative-evidence search not performed → STRONGLY_SUPPORTED prohibited
HIGH MARGIN / HIGH ROIC / MARKET SHARE / RECURRING REVENUE ≠ moat by themselves
```

Use `PRIMARY_MOAT + SUPPORTING_MECHANISMS` and the Removal Test.

Explicitly search for switching, migration, dual sourcing, internalization, substitution, design-arounds, new entry, pricing resistance and actual entry/exit.

---

# 24. RUNWAY BLOCK

Preserve:

```text
CURRENT GROWTH ≠ FUTURE RUNWAY
TAM ≠ SERVICEABLE MARKET ≠ REALISTIC CAPTURE POOL
RUNWAY ≠ CERTIFIED VALUE CREATION
```

Use the frozen causal proof chain from growth driver through denominator, current base, capture mechanism, observed capture, required reinvestment, constraints, moat-constrained right-to-win, dependency/double-count test, base-rate/fade challenge and negative evidence.

Canonical outputs:

```text
RUNWAY_EVIDENCE_STATE = UNKNOWN | PLAUSIBLE | SUPPORTED | STRONGLY_SUPPORTED
RUNWAY_MAGNITUDE = SMALL | MATERIAL | LARGE | UNKNOWN
RUNWAY_HORIZON = LIMITED | MODERATE | EXTENDED | UNKNOWN
```

Driver status:

```text
CORE | OPTIONALITY | EXCLUDED | UNKNOWN
```

Optionality does not lift Base runway until promoted by evidence.

Every material fade requires a causal `FADE_CAUSE`.

Top-down TAM alone cannot support more than `PLAUSIBLE` evidence.

---

# 25. RETURN QUALITY BLOCK

Preserve:

```text
BUSINESS ROIC ≠ CAPITAL-ALLOCATION ROIC ≠ MARGINAL ROIC
HIGH HISTORICAL ROIC ≠ HIGH FUTURE ROIIC
CALCULABLE ≠ ECONOMICALLY INTERPRETABLE
```

Use, where applicable:

```text
STANDARD ROIC
ALL-IN ROIC when acquisition capital is material
ROIIC when economically interpretable
ROIC EX-GOODWILL diagnostic
R&D-ADJUSTED ROIC when material
ACQUISITION / COHORT RETURN when relevant
```

Near-zero or negative invested capital may produce:

```text
ROIC = NOT_INTERPRETABLE
```

Use sector-valid alternatives rather than rewarding denominator instability.

ROIIC:

```text
ROIIC = Δ NORMALIZED NOPAT / Δ ECONOMIC INVESTED CAPITAL
```

only when sufficiently attributable and economically interpretable.

Default windows remain:

```text
1Y = DIAGNOSTIC ONLY
3Y = DEFAULT PRIMARY
5Y = CORROBORATION / LAG-AWARE
```

For acquisitive companies, preserve actual acquisition capital; impairments do not erase historical shareholder capital.

R&D adjustments require numerator / denominator symmetry.

Keep separate:

```text
DATA_QUALITY
ATTRIBUTABILITY
INTERPRETABILITY
```

---

# 26. FCF / OWNER EARNINGS / FORENSIC BLOCK

Preserve:

```text
NET INCOME ≠ CASH
CFO ≠ FCF
COMPANY-REPORTED FCF ≠ STANDARDIZED FCF
STANDARDIZED FCF ≠ OWNER EARNINGS
NON-CASH ≠ NON-ECONOMIC
RECURRING "ONE-OFF" ≠ ONE-OFF
```

For ordinary non-financials:

```text
STANDARDIZED_FCF = CFO - CASH_CAPEX
```

with explicit treatment of material leases, capitalized development, factoring, restructuring, acquisition costs, interest, taxes, working capital and classification issues.

Owner Earnings conceptually:

```text
NORMALIZED OPERATING CASH GENERATION
- MAINTENANCE REINVESTMENT
= OWNER EARNINGS
```

Owner Earnings may be:

```text
POINT | RANGE | UNKNOWN
```

Core forensic work includes cash conversion, working-capital forensic, capitalized costs, non-GAAP bridge, SBC/dilution, M&A accounting/impairments, audit/controls/restatements and sector-specific checks.

If `FORENSIC_RELIABILITY = FAIL`, do not convert the failure into a low score. Certification controls scoring permission.

---

# 27. CAPITAL ALLOCATION BLOCK

Analyze:

```text
ORGANIC REINVESTMENT
M&A
BUYBACKS
DIVIDENDS
DEBT
CASH RETENTION
EQUITY ISSUANCE
```

Use:

```text
CAPITAL GENERATED
→ CAPITAL DEPLOYED
→ RETURN ACHIEVED
→ PER-SHARE VALUE CREATION
```

Do not reward activity itself.

Return Quality measures project / cohort economics. Capital Allocation evaluates selection, sizing, funding, timing, discipline, portfolio decisions and per-share consequences.

Avoid scoring the same acquisition return twice.

---

# 28. MANAGEMENT / GOVERNANCE BLOCK

Analyze:

```text
CLAIMS VS OUTCOMES
INCENTIVES
OWNERSHIP
REMUNERATION
CAPITAL DISCIPLINE PROCESS
BOARD
SUCCESSION
RELATED PARTIES
MINORITY TREATMENT
```

Principle:

```text
STEWARDSHIP EVIDENCE > CHARISMA / NARRATIVE
```

Founder status, confidence, reputation or share-price performance are not standalone evidence of superior management.

---

# 29. OUTSIDE VIEW / BASE RATES

Use:

```text
REFERENCE CLASS
→ PRIOR
→ COMPANY-SPECIFIC EVIDENCE
→ UPDATED JUDGMENT
```

The prior is not the verdict.

Bottom-up evidence may legitimately move the judgment away from the reference-class prior.

Outside View must challenge, not mechanically override, the company-specific analysis.

---

# 30. RISK / RESILIENCE BLOCK

Risk categories are limited to the frozen taxonomy:

```text
TEMPORARY
CYCLICAL
STRUCTURAL
FINANCIAL
DISRUPTION
REGULATORY
GOVERNANCE
CONCENTRATION
EXECUTION
```

For each material risk retain:

```text
EVIDENCE
TRANSMISSION_MECHANISM
SEVERITY
DETECTABILITY
REVERSIBILITY
THESIS_IMPACT
EARLY_INDICATOR
```

Do not create a pseudo-precise probability × severity score.

Material weak-link analysis remains cross-block and non-compensatory.

---

# 31. RED TEAM / PRE-MORTEM

Mandatory before valuation certification and scoring.

At minimum challenge:

```text
DISCONFIRMING EVIDENCE
THESIS-BREAKING CASE
COMPETITOR CHALLENGE
CUSTOMER CHALLENGE
REGULATOR CHALLENGE
ACCOUNTING / CASH CHALLENGE
RUNWAY FAILURE
ROIIC FAILURE
REVERSE-VALUATION CHALLENGE
PRE-MORTEM
```

Ask:

> If this investment disappoints badly, what were the most likely reasons already visible at `DATA_CUTOFF`?

Red Team must be allowed to reopen upstream blocks.

No cognitive-bias score is created.

---

# 32. VALUATION / EXPECTED RETURN

Keep distinct:

```text
INTRINSIC VALUE
≠ EXPECTED SHAREHOLDER RETURN
≠ MARKET-IMPLIED EXPECTATIONS
```

Canonical valuation order:

```text
IDENTITY / MARKET LOCK
→ VALUATION BASIS
→ MARKET-IMPLIED EXPECTATIONS
→ FUNDAMENTAL FORECAST
→ DCF / INTRINSIC VALUE
→ EXPECTED RETURN 5Y / 10Y
→ NORMALIZED MULTIPLE CROSS-CHECK
→ SENSITIVITY / RED TEAM
→ PRICE LADDER
→ MARGIN OF SAFETY
→ VALUATION RELIABILITY
```

Basis matching:

```text
FCFF → WACC
FCFE / OWNER EARNINGS → COST OF EQUITY
```

Never mix cash-flow and discount-rate bases.

Preserve:

```text
ECONOMIC DISCOUNT RATE ≠ INVESTOR REQUIRED RETURN H
```

The current locked V1 policy is inherited, not redefined here:

```text
REQUIRED_RETURN_H = 10.0%
STRONG_RETURN_THRESHOLD = 12.5%
EXCEPTIONAL_RETURN_THRESHOLD = 15.0%
```

The stage must load the exact locked policy version rather than hard-code future policy changes from memory.

Fundamental forecasts must be driver-based where material drivers are reconstructible.

Reinvestment consistency:

```text
GROWTH ≈ REINVESTMENT RATE × EXPECTED MARGINAL RETURN
```

Forecast share count must include economically relevant issuance, SBC, acquisition shares and buybacks.

Terminal economics must maintain internal consistency between growth, reinvestment and terminal return on new capital.

Primary intrinsic terminal method remains stable-economics / perpetual-growth. Exit multiples are cross-check / expected-return scenario tools, not the default independent intrinsic-value engine.

Reverse DCF is Core and solves a limited material variable set rather than many underdetermined variables simultaneously.

Scenarios are causal, not arbitrary percentages.

Expected return uses exact IRR / geometric shareholder-return logic where applicable.

5Y should be produced when defensible; 10Y only when the economic horizon supports it.

---

# 33. MATURE NORMALIZATION / N-SELECTION EXECUTION PATCH

For OVS `N` selection, apply the locked execution rule exactly:

```text
IF MATURE_NORMALIZATION_RETURN is valid + numeric + reconciled + certifiable
→ N = MATURE_NORMALIZATION_RETURN

ELSE IF MATURE_NORMALIZATION_RETURN is legitimately non-numeric
     because NOT_ASSESSABLE / NOT_AVAILABLE after required work
     AND NO_MULTIPLE_EXPANSION_RETURN is valid + numeric + interpretable
→ N = NO_MULTIPLE_EXPANSION_RETURN

ELSE IF MATURE_NORMALIZATION_RETURN exists but is invalid / unreconciled
→ FAIL CLOSED
→ DO NOT FALL BACK AROUND THE FAILURE
```

An invalid calculation is not a legitimate fallback condition.

This section is execution inheritance, not a methodological recalibration.

---

# 34. MARGIN OF SAFETY / PRICE LADDER / VALUATION RELIABILITY

MOS states:

```text
ROBUST
ADEQUATE
THIN
NONE
NOT_ASSESSABLE
```

MOS is not merely `fair value - price`; it must reflect adverse-case absorption, expected return, normalized/no-expansion return, terminal dependence, sensitivity and reliability.

Price Ladder solves entry prices from the same frozen fundamentals for configured return hurdles.

At minimum under the current locked policy:

```text
PRICE_FOR_REQUIRED_RETURN_H
PRICE_FOR_STRONG_RETURN
PRICE_FOR_EXCEPTIONAL_RETURN
```

Valuation Reliability:

```text
HIGH
MEDIUM
LOW
NOT_ASSESSABLE
```

A high-quality business may legitimately have `VALUATION_RELIABILITY = NOT_ASSESSABLE`.

---

# 35. SECTOR / BUSINESS-MODEL OVERLAYS

Apply all economically relevant overlays; they are composable.

Examples include:

```text
SOFTWARE
MARKETPLACE
INDUSTRIAL
INSTALLED BASE / MEDTECH
DATA / TESTING / CERTIFICATION
SERIAL ACQUIRER
BANK
INSURANCE
LUXURY / BRAND
CYCLICAL / COMMODITY-LIKE
```

Rules include:

```text
BANK:
industrial ROIC / industrial FCF = NOT_APPLICABLE
use valid equity-return / capital-generation framework

INSURANCE:
industrial FCF not headline
use underwriting / normalized ROE / distributable-capital economics

MARKETPLACE:
explosive near-zero-denominator ROIC ≠ elite return quality

SERIAL ACQUIRER:
All-In return + acquisition capital / cohort economics required when material

CYCLICAL:
normalize mid-cycle NOPAT / capital / FCF / marginal return / valuation
```

Canonical state:

```text
SECTOR_METHOD_STATUS
= APPLIED | NOT_REQUIRED | MISSING | WRONG_METHOD
```

A raw metric may be `NOT_APPLICABLE` while the economic dimension remains fully scoreable through a valid substitute.

---

# 36. CROSS-BLOCK RECONCILIATION

Before Certification, reconcile at minimum:

```text
IDENTITY / DATES ↔ ALL BLOCKS
MOAT ↔ RUNWAY
RUNWAY ↔ RETURN QUALITY
RETURN QUALITY ↔ FCF
FCF ↔ VALUATION
MOAT ↔ TERMINAL ECONOMICS
FORENSIC ↔ DATA RELIABILITY
SBC ↔ SHARE COUNT
M&A ↔ ACQUISITION CAPITAL / CAPITAL ALLOCATION / VALUATION
RISKS ↔ VALUATION SCENARIOS
```

Examples of invalid unreconciled combinations:

```text
RUNWAY requires heavy reinvestment
but valuation assumes growth with zero reinvestment

MOAT = ERODING
but terminal economics assume permanent excess returns without fade

FCF shows material dilution
but valuation assumes flat shares

historical acquisition returns are weak
but valuation assumes exceptional future M&A returns without new evidence
```

Material cross-block contradiction is a Certification hard blocker.

---

# 37. RESEARCH CERTIFICATION

Certification is a non-compensatory gate system, not a score.

Certification sequence:

```text
IDENTITY + POINT-IN-TIME LOCK
→ EVIDENCE PROVENANCE
→ DATA-DEFINITION LOCK
→ CALCULATION + RECONCILIATION
→ BLOCK EXECUTION
→ CROSS-BLOCK CONSISTENCY
→ CONFLICT + ASSUMPTION GATES
→ RED TEAM / PRE-MORTEM CHECK
→ FINAL-OUTPUT TRACEABILITY
→ DUAL CERTIFICATION DECISION
```

Always produce:

```text
BUSINESS_RESEARCH_STATUS
INVESTMENT_CONCLUSION_STATUS
```

using:

```text
CERTIFIED
CERTIFIED_WITH_LIMITATIONS
NOT_CERTIFIED
INSUFFICIENT_DATA
```

Always produce before scoring:

```text
SCORE_PERMISSION
= ALLOWED | CONDITIONAL | SUSPENDED
```

Key rules:

```text
BUSINESS_RESEARCH_STATUS = NOT_CERTIFIED
→ NO OQS

SCORE_PERMISSION = SUSPENDED
→ NO FINAL SCORE

VALUATION NOT CERTIFIABLE
→ OQS may exist
→ OVS / INVESTMENT_SCORE prohibited
```

No score-with-an-asterisk workaround is allowed.

---

# 38. HARD BLOCKERS B1–B8

Certification must test:

```text
B1 IDENTITY LOCK FAILURE
B2 MATERIAL CALCULATION / RECONCILIATION FAILURE
B3 MATERIAL EVIDENCE INTEGRITY FAILURE
B4 FORENSIC RELIABILITY = FAIL
B5 CRITICAL DEFINITION / BASIS / METHOD FAILURE
B6 CRITICAL INFORMATION GAP
B7 MATERIAL CROSS-BLOCK CONTRADICTION
B8 MATERIAL POINT-IN-TIME / VERSION / FRESHNESS FAILURE
```

For B6 distinguish:

```text
MISSING REQUIRED WORK → NOT_CERTIFIED
HONEST CRITICAL UNKNOWN AFTER ADEQUATE RESEARCH → INSUFFICIENT_DATA
```

---

# 39. SCORING FIREWALL

Scoring begins only after Certification grants permission.

The seven quality dimensions remain:

```text
MOAT 20%
RUNWAY 15%
RETURN_QUALITY 20%
CASH_ECONOMICS 10%
CAPITAL_ALLOCATION 15%
MANAGEMENT_GOVERNANCE 10%
RESILIENCE_RISK 10%
```

Dimension judgments use the frozen 5-point anchor precision.

OQS, OVS, Investment Score, caps, evidence ceilings and investment classes are deterministic once their canonical inputs are fixed.

The Lead Analyst supplies / locks judgment inputs; it does not override formula outputs.

```text
ANALYST CONVICTION
≠ SCORE OVERRIDE
```

If the implementation exposes the canonical I2 computation engine, use it.

If a provisional calculation is produced outside I2, it must remain fully reproducible in the Calculation Ledger and is subject to mandatory I2 reconciliation before canonical publication.

---

# 40. OVS EXECUTION

Apply the frozen expected-return-led OVS architecture.

The current policy uses `H` from the exact locked investment-policy version.

Preserve:

```text
ΔER = PRIMARY_EXPECTED_RETURN - H
RETURN_COMPONENT = MIN(0.60 × C + 0.40 × N, N + 15)
```

and the frozen MOS / valuation-reliability caps.

No OVS exists when the frozen method says it is not assessable.

Reverse DCF is an expectation-consistency check, not a separate score contribution.

---

# 41. INVESTMENT SCORE EXECUTION

Use the frozen deterministic synthesis only.

```text
INVESTMENT_RAW = 0.70 × OQS + 0.30 × OVS
INVESTMENT_SCORE = MIN(INVESTMENT_RAW, OQS, OVS + 15)
```

No analyst override is allowed.

A cheap price cannot transform a weak business into an exceptional-quality business.

---

# 42. OROTITAN TERMINAL GATE

OroTitan is a terminal eligibility state, not a score band.

```text
OROTITAN_STATUS = YES
```

iff the frozen conjunctive conditions all pass, including:

```text
FULL CERTIFICATION
MOAT_ELITE
RUNWAY_ELITE
RETURN_QUALITY_ELITE
CASH_ECONOMICS_ELITE
CAPITAL_ALLOCATION_ELITE
MANAGEMENT_GOVERNANCE_ELITE
RESILIENCE_ELITE
VALUATION_ELITE
MATERIAL_WEAK_LINK = NO
```

Elite states use:

```text
PASS | FAIL | NOT_ASSESSABLE
```

High OQS / Investment Score alone can never produce OroTitan status.

`OROTITAN_PROXIMITY_SCORE` is prohibited.

Zero OroTitans is a valid result.

---

# 43. MATERIAL WEAK LINK

Preserve the frozen non-compensatory test.

A material weak link exists when all three hold:

```text
MATERIALITY
+
CAUSALITY
+
UNRESOLVEDNESS
```

A cross-block weakness may fail OroTitan even if no individual dimension score appears low.

```text
MATERIAL_WEAK_LINK = YES
→ OROTITAN_STATUS = NO
```

---

# 44. READINESS / NEXT ACTION

Dossier Readiness remains:

```text
READY
PARTIALLY_READY
NOT_READY
```

No readiness score exists.

Readiness is operational capability, not quality and not a mandatory waiting stage.

Canonical Next Action remains:

```text
INVESTABLE_NOW
WAIT_FOR_PRICE
WAIT_FOR_EVIDENCE
REFRESH_REQUIRED
REJECT
```

Price movement does not rewrite business quality.

Prepared opportunities remain valid:

```text
excellent business
+ wrong current price
→ READY + WAIT_FOR_PRICE
```

when all frozen conditions support it.

---

# 45. REFRESH / ACTIVATION EXECUTION

For `REFRESH`, consume the Research-stage delta classifier:

```text
PRICE_ONLY_DELTA
ROUTINE_FUNDAMENTAL_DELTA
FULL_REFRESH_REQUIRED
```

## 45.1 PRICE_ONLY_DELTA

Do not reopen unaffected fundamental quality blocks solely because price changed.

Update only valuation-dependent fields and downstream deterministic outputs as authorized.

OQS remains unchanged if fundamentals are unchanged.

## 45.2 ROUTINE_FUNDAMENTAL_DELTA

Reopen affected analytical blocks and material downstream dependencies identified by analyst judgment.

Prior canonical outputs are knowledge, not presumed current truth.

## 45.3 FULL_REFRESH_REQUIRED

Re-execute the full required analytical chain using re-established Research sufficiency.

## 45.4 ACTIVATION CHECK

A prepared-dossier price-zone crossing is not a buy signal.

Run the frozen Activation Check, refresh required valuation data / relevant deltas, rerun downstream certification / scoring / terminal logic as required.

---

# 46. PRIOR CANONICAL RESEARCH

Core rule:

```text
PREVIOUS CANONICAL RESEARCH
= KNOWLEDGE BASE
≠ CURRENT EVIDENCE BY DEFAULT
```

Material inherited conclusions used in the current run must be revalidated.

Useful execution labels:

```text
REVALIDATED
UPDATED
SUPERSEDED
INVALIDATED
```

No blanket presumption of truth attaches to prior conclusions.

---

# 47. READY FOR INTEGRATION

`READY_FOR_INTEGRATION` is an execution-stage handoff gate, not a business-quality verdict.

It may be `YES` when all required Deep Dive work has reached a valid canonical representable outcome, including honest negative or limited outcomes.

It does **not** require:

```text
OROTITAN_STATUS = YES
INVESTABLE_NOW
CERTIFIED without any limitation
HIGH SCORE
```

It does require, for the run scope:

```text
DEEP DIVE PRE-FLIGHT = PASS
REQUIRED ANALYTICAL WORK EXECUTED OR HONESTLY RESOLVED INTO ALLOWED FROZEN STATES
VALUATION STATE PRODUCED AS FAR AS METHOD PERMITS
CERTIFICATION EXECUTED
SCORE_PERMISSION OBEYED
SCORING EXECUTED ONLY WHEN PERMITTED
TERMINAL GATE EXECUTED WHEN DETERMINABLE / REQUIRED
READINESS / NEXT_ACTION PRODUCED
MATERIAL OUTPUTS TRACEABLE
NO CONTRACT DRIFT
NO UNRESOLVED EXECUTION DEFECT THAT PREVENTS CANONICAL REPRESENTATION
AUTHORITATIVE ARTIFACTS PERSISTED / VERSIONED
REGISTRY RECONCILED
```

Examples that may still be integration-ready:

```text
CERTIFIED_WITH_LIMITATIONS
INVESTMENT_CONCLUSION_STATUS = INSUFFICIENT_DATA after adequate research
OROTITAN_STATUS = NO
WAIT_FOR_PRICE
WAIT_FOR_EVIDENCE
REJECT
```

provided these are valid frozen outcomes rather than unfinished work.

Examples that are not integration-ready:

```text
IDENTITY LOCK FAILURE
REQUIRED WORK SIMPLY NOT PERFORMED
CONTRACT VERSION MISMATCH
MATERIAL UNRECONCILED METHOD DEFECT
PERSISTENCE FAILURE
```

---

# 48. AUTHORITATIVE DEEP DIVE ARTIFACTS

Persist at minimum conceptually:

```text
1. DEEP_DIVE_REPORT
2. UPDATED EVIDENCE_LEDGER VERSION / REFERENCES
3. CONFLICT_LEDGER VERSION / REFERENCES
4. CALCULATION_LEDGER
5. MATERIAL_ASSUMPTION_REGISTER
6. ANALYTICAL_BLOCK_OUTPUTS
7. CROSS_BLOCK_RECONCILIATION_RECORD
8. RED_TEAM_PREMORTEM_RECORD
9. VALUATION_ARTIFACT
10. CERTIFICATION_ARTIFACT
11. SCORING_INPUTS / OUTPUTS when permitted
12. OROTITAN_TERMINAL_GATE_ARTIFACT
13. READINESS_NEXT_ACTION_ARTIFACT
14. DEEP_DIVE_STAGE_MANIFEST
```

Exact physical layout is an implementation detail.

Do not create incompatible duplicate semantics for already-frozen ledgers.

---

# 49. DEEP DIVE FINAL REPORT PRESENTATION

Execution order and report presentation order are distinct.

The final report should surface decision-useful outcomes early while preserving traceability.

At minimum it should make easy to find:

```text
EXECUTIVE SUMMARY
CERTIFICATION STATUS
IDENTITY / DATA LOCK
BUSINESS MODEL
ECONOMIC QUALITY
MOAT
RUNWAY
RETURN QUALITY
FCF / FORENSIC
CAPITAL ALLOCATION
MANAGEMENT / GOVERNANCE
OUTSIDE VIEW
RISK / RESILIENCE
RED TEAM
VALUATION / EXPECTED RETURN
SCORING if permitted
OROTITAN TERMINAL GATE
READINESS / NEXT ACTION
LIMITATIONS / INVALIDATION TRIGGERS
```

Presentation must not alter calculation or dependency order.

---

# 50. SELF-AUDIT BEFORE COMPLETION

The Lead Analyst must ask:

```text
Was the exact run / company / security analyzed?
Was DATA_CUTOFF respected?
Were exact Research artifacts loaded?
Did new material evidence enter the Evidence Ledger?
Were material conflicts registered rather than silently resolved?
Were assumptions kept separate from facts?
Are material calculations reproducible?
Were sector overlays applied correctly?
Did every required analytical block execute or reach an allowed frozen state?
Did any block need reopening?
Was cross-block reconciliation performed?
Was Red Team / Pre-Mortem completed?
Was valuation basis matched correctly?
Was N-selection applied exactly?
Was Certification completed before scoring?
Was SCORE_PERMISSION obeyed?
Were deterministic score formulas left un-overridden?
Was terminal OroTitan determined conjunctively rather than by score band?
Was Dossier Readiness kept separate from investability?
Are all material conclusions traceable to Evidence / Calculation IDs?
Did we avoid summary-as-authority?
Did we avoid post-cutoff contamination?
```

Any material `NO` prevents normal completion until repaired or represented through a valid frozen limitation / insufficiency state.

---

# 51. STAGE FINALIZATION

Deep Dive may be `COMPLETE` only after:

```text
1. REQUIRED DEEP DIVE WORK COMPLETE OR VALIDLY RESOLVED INTO ALLOWED FROZEN STATES
2. LEAD-ANALYST SELF-AUDIT COMPLETE
3. AUTHORITATIVE ARTIFACTS GENERATED
4. ARTIFACTS PERSISTED / VERSIONED
5. REGISTRY RECONCILED
6. DEEP_DIVE_STAGE_STATUS UPDATED
7. READY_FOR_INTEGRATION DECLARED
8. HUMAN SUMMARY PRODUCED
9. PILOTAGE HANDOFF PRODUCED
10. STOP AT STAGE BOUNDARY
```

If persistence or registry reconciliation fails:

```text
DEEP_DIVE_STAGE_STATUS != COMPLETE
READY_FOR_INTEGRATION = NO
```

A narrative answer alone never completes the stage.

---

# 52. HUMAN SUMMARY

At completion, provide approximately 10–15 lines covering:

```text
economic thesis
strongest evidence
material weaknesses / negative evidence
key risks
key uncertainties
Certification outcome
OQS / OVS / Investment Score if permitted
valuation / expected return if certifiable
OroTitan terminal result
Dossier Readiness / Next Action
```

This is for the user only.

```text
HUMAN SUMMARY
≠ INTEGRATION INPUT AUTHORITY
```

---

# 53. PILOTAGE HANDOFF

Emit compact fallback routing metadata:

```text
COMPANY
RUN_ID
STAGE = DEEP_DIVE
DEEP_DIVE_STAGE_STATUS
DATA_CUTOFF
BUSINESS_RESEARCH_STATUS
INVESTMENT_CONCLUSION_STATUS
SCORE_PERMISSION
READY_FOR_INTEGRATION
AUTHORITATIVE_ARTIFACT_IDS / VERSIONS
CRITICAL_BLOCKERS
OPEN_MATERIAL_LIMITATIONS
NEXT_STAGE
```

Normal path:

```text
Pilotage retrieves authoritative registry state directly.
```

Fallback handoff is routing metadata only and cannot become analytical evidence.

---

# 54. FAIL-CLOSED RULES

At minimum:

```text
RUN_ID / COMPANY / SECURITY MISMATCH
→ STOP

CONTRACT VERSION MISMATCH
→ STOP

RESEARCH ARTIFACT ID / VERSION / STATUS MISMATCH
→ STOP

REQUIRED RESEARCH SCOPE NOT SUFFICIENT
→ AFFECTED DEEP DIVE WORK BLOCKED

POST-CUTOFF MATERIAL EVIDENCE
→ EXCLUDE / REQUIRE CONTROLLED NEW CUTOFF

MATERIAL EVIDENCE CONFLICT UNRESOLVED
→ AFFECTED OUTPUT CANNOT LOCK / CERTIFY AS APPLICABLE

MATERIAL CALCULATION / RECONCILIATION FAILURE
→ CERTIFICATION BLOCKER

WRONG SECTOR METHOD
→ CERTIFICATION BLOCKER

RED TEAM NOT COMPLETED
→ NO FULL CERTIFICATION / NO NORMAL SCORING

INVALID MATURE-NORMALIZATION CALCULATION
→ FAIL CLOSED
→ NO SAME-MULTIPLE FALLBACK AROUND FAILURE

SCORE_PERMISSION = SUSPENDED
→ NO FINAL SCORE

VALUATION NOT CERTIFIABLE
→ NO OVS / INVESTMENT SCORE

PERSISTENCE / REGISTRY FAILURE
→ STAGE NOT COMPLETE

HUMAN SUMMARY ONLY
→ NOT ACCEPTED AS STAGE ARTIFACT
```

Unknowns remain unknown.

---

# 55. ACCEPTANCE TESTS REQUIRED BEFORE FREEZE

Validate at minimum:

```text
D01 Initial imposed company / clean Research handoff
D02 Discovery → DEEP_DIVE_CANDIDATE handoff
D03 Human Research summary without artifacts
D04 Research artifact version mismatch
D05 Contract version mismatch
D06 Post-cutoff source discovered during analysis
D07 Material source conflict during Deep Dive
D08 New evidence reopens previously sufficient Moat block
D09 Negative evidence falsifies initial moat hypothesis
D10 Top-down TAM only cannot support strong Runway
D11 Near-zero invested capital makes ROIC non-interpretable
D12 Serial acquirer requires All-In / acquisition-return economics
D13 Bank uses sector-valid substitutes
D14 Insurer uses sector-valid substitutes
D15 Forensic reliability failure suspends affected certification/scoring
D16 Red Team reopens Runway / Return Quality
D17 Valuation cash-flow / discount-rate basis mismatch
D18 Mature-normalization valid numeric takes precedence
D19 Mature-normalization legitimately non-numeric permits valid same-multiple fallback
D20 Mature-normalization invalid / unreconciled fails closed
D21 Valuation not assessable allows business OQS when certification permits but no OVS / Investment Score
D22 SCORE_PERMISSION = SUSPENDED blocks final score
D23 Analyst attempts manual score override
D24 High scores but one Elite gate fails → OROTITAN_STATUS = NO
D25 Material weak link exists despite strong dimensions → OROTITAN_STATUS = NO
D26 PRICE_ONLY_DELTA preserves OQS when fundamentals unchanged
D27 ROUTINE_FUNDAMENTAL_DELTA reopens affected blocks + downstream dependencies
D28 FULL_REFRESH_REQUIRED re-executes full required chain
D29 Previous canonical conclusion not treated as current evidence automatically
D30 Honest INSUFFICIENT_DATA outcome can still be canonically representable
D31 Persistence failure blocks Deep Dive completion
D32 Summary used as Integration input is rejected
D33 I2 deterministic outputs must reconcile exactly
D34 Final report introduces a number not present in evidence/calculation artifacts → fail traceability
```

Required invariants:

```text
NO METHODOLOGY DRIFT
NO SCORE-FIRST ANALYSIS
NO VALUATION-FIRST ANALYSIS
NO SILENT ASSUMPTION CREATION
NO SILENT CONFLICT RESOLUTION
NO POST-CUTOFF CONTAMINATION
NO SUMMARY-AS-AUTHORITY
NO SCORE OVERRIDE
NO TERMINAL STATUS FROM SCORE BAND
NO OROTITAN PROXIMITY SCORE
NO INVALID N-FALLBACK
NO STAGE COMPLETION WITHOUT PERSISTENCE
```

---

# 56. CURRENT STATUS

```text
DOCUMENT = OROTITAN_DEEP_DIVE_STAGE_CONTRACT_V1_FREEZE_V1.0
STATUS = FROZEN
FREEZE_VERSION = 1.0
FREEZE_DATE = 2026-09-12
METHODOLOGY_CHANGE = NO

FREEZE BASIS:
→ CONTRACT v0.1
→ TARGETED_VALIDATION_v0.1 = PASS
→ SCENARIO_TESTS = 34 / 34 PASS
→ USER_CONTINUATION_AUTHORIZATION = YES

RUNTIME IMPLEMENTATION STATUS:
→ NOT YET IMPLEMENTED
→ CONTRACT FREEZE DOES NOT CLAIM LIVE ORCHESTRATION EXISTS

NEXT:
→ BUILD + VALIDATE INTEGRATION_STAGE_CONTRACT
```
