# OROTITAN_RESEARCH_STAGE_CONTRACT_V1 — FREEZE V1.0

**Project:** OroTitan Equity Research  
**Contract type:** Company Research Stage execution contract  
**Status:** FROZEN — V1.0  
**Depends on:** `OROTITAN_RESEARCH_EXECUTION_PROCESS_V1_FREEZE_V1.0` and `OROTITAN_PILOTAGE_ORCHESTRATION_CONTRACT_V1_FREEZE_V1.0`  
**Methodology change:** NO

---

# 0. PURPOSE

The Research Stage builds the authoritative evidence base required for a later Deep Dive.

It answers:

> **Do we have enough reliable, current and sufficiently independent evidence to allow each required Deep Dive block to be analyzed honestly?**

It does **not** answer:

> Is this a great company?

> Is the moat durable?

> Is the stock cheap?

> Is the company OroTitan?

Core rule:

```text
RESEARCH
= EVIDENCE ACQUISITION + NORMALIZATION + GAP CLOSURE + INPUT SUFFICIENCY

RESEARCH
≠ FINAL ANALYSIS
≠ FINAL VERDICT
≠ SCORING
≠ VALUATION
≠ OROTITAN GATE
```

---

# 1. AUTHORITY HIERARCHY

Research obeys:

```text
1. FROZEN ANALYTICAL METHODOLOGY
2. LOCKED INVESTMENT POLICY / EXECUTION PATCHES / I2 / I3-B
3. OROTITAN_RESEARCH_EXECUTION_PROCESS_V1_FREEZE_V1.0
4. RESEARCH_STAGE_CONTRACT_V1
5. RUN-SPECIFIC BOOTSTRAP
```

Any conflict with a higher authority causes:

```text
CONTRACT_DRIFT = DETECTED
→ PRE_FLIGHT = FAIL
→ STOP
→ RETURN TO PILOTAGE
```

---

# 2. STAGE ROLE

Research is responsible for:

```text
COLLECT
NORMALIZE
VERIFY
CHALLENGE
SOURCE-DIVERSIFY
IDENTIFY GAPS
CLOSE GAPS WHERE REASONABLY POSSIBLE
REGISTER CONFLICTS
FORMULATE MATERIAL RESEARCH HYPOTHESES
ASSESS DD INPUT SUFFICIENCY
PERSIST AUTHORITATIVE RESEARCH ARTIFACTS
```

Research is not responsible for:

```text
FINAL MOAT VERDICT
FINAL RUNWAY VERDICT
FINAL RETURN-QUALITY VERDICT
FINAL FCF / FORENSIC VERDICT
FINAL CAPITAL-ALLOCATION VERDICT
FINAL MANAGEMENT / GOVERNANCE VERDICT
FINAL RISK / RESILIENCE VERDICT
DCF / FAIR VALUE / PRICE TARGET
OQS / OVS / INVESTMENT SCORE
OROTITAN TERMINAL GATE
```

---

# 3. PRE-FLIGHT

Before any research work:

```text
1. Resolve RUN_ID.
2. Verify COMPANY / ISSUER identity.
3. Verify CANONICAL_MODE / RUN_TYPE.
4. Verify DATA_CUTOFF.
5. Load exact RESEARCH_STAGE_CONTRACT version.
6. Verify process-contract compatibility.
7. Resolve baseline canonical snapshot if REFRESH.
8. Inventory user-provided documents already available to the run.
9. Verify no prior stage blocker makes Research invalid.
```

If any mandatory item fails:

```text
PRE_FLIGHT = FAIL
→ DO NOT RESEARCH
→ REPORT EXACT FAILURE
→ RETURN TO PILOTAGE
```

---

# 4. POINT-IN-TIME DISCIPLINE

All evidence used by the run must satisfy the run cutoff.

```text
SOURCE_DATE <= DATA_CUTOFF
```

unless the source is used solely to understand a historical document that itself predates the cutoff without leaking later factual knowledge into the run.

Post-cutoff information must not rewrite the run.

If a material post-cutoff source is required:

```text
CURRENT RUN
→ DO NOT ABSORB IT SILENTLY
→ REQUIRE NEW / REFRESH RUN WITH NEW DATA_CUTOFF
```

Keep distinct:

```text
SOURCE_DATE
DATA_PERIOD
DATA_CUTOFF
REFERENCE_PRICE_DATE
CALCULATION_DATE
```

---

# 5. USER-PROVIDED MATERIAL

At Research start, the user may attach any documents already possessed.

Research must:

```text
1. INVENTORY them.
2. IDENTIFY document type / date / issuer relevance.
3. DETECT duplicates / superseded versions where possible.
4. REGISTER useful documents in the source manifest.
5. DETERMINE what is still missing.
6. SEARCH autonomously for the rest.
```

The user is not required to know the complete document checklist.

Research must not turn the user into the default document collector.

---

# 6. AUTONOMOUS SEARCH RESPONSIBILITY

Research is responsible for searching, where relevant, across:

```text
ISSUER / INVESTOR RELATIONS
REGULATORY FILINGS
EXCHANGE / MARKET AUTHORITIES
ANNUAL / INTERIM REPORTS
EARNINGS MATERIALS
CAPITAL-MARKETS / INVESTOR-DAY MATERIALS
GOVERNANCE / REMUNERATION DOCUMENTS
CUSTOMERS
SUPPLIERS
DISTRIBUTORS
COMPETITORS
INDUSTRY ASSOCIATIONS
REGULATORS
STANDARD-SETTING / CERTIFICATION BODIES
PATENT / TECHNICAL MATERIAL where relevant
TRADE PUBLICATIONS
ACADEMIC / TECHNICAL RESEARCH where relevant
REPUTABLE NEWS / INVESTIGATIVE SOURCES
MARKET / INDUSTRY DATA SOURCES
```

Research must search both:

```text
FOR THE HYPOTHESIS
AND
AGAINST THE HYPOTHESIS
```

A purely confirmatory research pack is insufficient for full DD input sufficiency.

---

# 7. SOURCE PRIORITY AND CLAIM FIT

Research preserves the frozen evidence discipline.

Use the best source for the specific claim, not a single universal source ranking.

Examples:

```text
AUDITED FINANCIAL VALUE
→ issuer filing / audited accounts preferred

MARKET SHARE
→ independent industry / customer / channel evidence may be superior to issuer claim

CUSTOMER SWITCHING FRICTION
→ customer / implementation / procurement evidence may be more probative than issuer marketing

REGULATORY REQUIREMENT
→ regulator / standard-setter / legal text preferred

CURRENT MARKET PRICE
→ reliable exchange / market-data source
```

Issuer assertions are evidence of what management says, not independent proof of the underlying economic claim.

---

# 8. AUTHORITATIVE EVIDENCE LEDGER

There is one authoritative Evidence Ledger for the run lineage/version.

Do not create competing “primary” and “external” evidence authorities.

Every material evidence item should retain the frozen evidence semantics, including as applicable:

```text
EVIDENCE_ID
CLAIM_ID
CLAIM / METRIC
VALUE / STATEMENT
PERIOD / AS_OF_DATE
SOURCE
ROOT_SOURCE_ID
INDEPENDENCE_GROUP
SOURCE_CLASS
CLAIM_FIT
SOURCE_DATE
DATA_CUTOFF
EPISTEMIC_TYPE
FRESHNESS_STATE
LIMITATIONS
CONFLICT_STATUS
```

Research may expose filtered views such as:

```text
ISSUER SOURCES
INDEPENDENT SOURCES
CUSTOMER EVIDENCE
COMPETITOR EVIDENCE
REGULATORY EVIDENCE
```

but those are views over one ledger.

---

# 9. ROOT-SOURCE RULE

When a secondary source points to a root source that is reasonably obtainable:

```text
SECONDARY SOURCE
→ LOCATE ROOT SOURCE
→ REGISTER ROOT SOURCE
→ USE SECONDARY SOURCE ONLY FOR ITS DISTINCT VALUE
```

Research must not repeatedly cite derivative summaries when the underlying source is available.

If the root source is inaccessible, record the limitation explicitly.

---

# 10. CONFLICT HANDLING

Material conflicting evidence must use the frozen Conflict Ledger semantics.

At minimum preserve:

```text
CONFLICT_ID
METRIC / CLAIM
SOURCE_A / VALUE_A / EVIDENCE_ID_A
SOURCE_B / VALUE_B / EVIDENCE_ID_B
CONFLICT_TYPE
REASON
RESOLUTION = RESOLVED | UNRESOLVED
MATERIALITY
AFFECTED_OUTPUTS[]
```

Rule:

```text
NEVER CHOOSE THE CONVENIENT NUMBER SILENTLY
```

A material unresolved conflict can make a DD input block `INSUFFICIENT`.

---

# 11. RESEARCH HYPOTHESES

Research may formulate hypotheses to direct evidence collection.

## 11.1 Material hypothesis

Must be formalized if it can materially alter a later analytical block or final conclusion.

Minimum execution record:

```text
HYPOTHESIS_ID
AFFECTED_ANALYTICAL_BLOCK
HYPOTHESIS
WHY_MATERIAL
SUPPORTING_EVIDENCE_IDS[]
CONTRADICTING_EVIDENCE_IDS[]
UNRESOLVED_POINTS[]
RESEARCH_STATUS
```

Example:

```text
The installed service network may create a meaningful replacement / switching barrier.
```

## 11.2 Tactical hypothesis

Temporary search ideas may remain informal.

## 11.3 Boundary

Research hypothesis:

```text
"X may be a moat mechanism"
```

is allowed.

Final verdict:

```text
"X is a durable moat"
```

belongs to Deep Dive.

---

# 12. ADAPTIVE RESEARCH PLAN

Research uses:

```text
UNIVERSAL CORE
+
COMPANY / BUSINESS-MODEL / SECTOR ADAPTATION
```

The stage must not impose arbitrary document-count rules.

Wrong standard:

```text
"We have 8 reports, so Research is complete."
```

Correct standard:

```text
"Every required DD input block has enough fit-for-purpose evidence to support an honest Deep Dive conclusion."
```

---

# 13. DD INPUT SUFFICIENCY NAMESPACE

This contract introduces an **execution-layer** sufficiency gate.

It must never be confused with frozen Discovery `DATA_SUFFICIENCY`, Dossier Readiness or Certification.

Use:

```text
DD_INPUT_STATUS
= SUFFICIENT
| INSUFFICIENT
| NOT_APPLICABLE
```

Do not use `PARTIALLY_SUFFICIENT` as an admission state.

A block may be well researched and still have a negative future analytical verdict.

```text
INPUT SUFFICIENCY
≠ ANALYTICAL QUALITY
```

---

# 14. REQUIRED DD INPUT BLOCKS

For INITIAL and FULL_REFRESH_REQUIRED runs, assess at minimum:

```text
IDENTITY_PIT_INPUTS
BUSINESS_MODEL_INPUTS
MOAT_INPUTS
RUNWAY_INPUTS
RETURN_QUALITY_INPUTS
FCF_FORENSIC_INPUTS
CAPITAL_ALLOCATION_INPUTS
MANAGEMENT_GOVERNANCE_INPUTS
OUTSIDE_VIEW_INPUTS
RISK_RESILIENCE_INPUTS
VALUATION_INPUTS
```

For each block record:

```text
BLOCK_ID
APPLICABILITY
DD_INPUT_STATUS
MANDATORY_COVERAGE
EVIDENCE_ADEQUACY
MATERIAL_BLOCKING_GAPS[]
KEY_EVIDENCE_IDS[]
KEY_CONFLICT_IDS[]
SEARCHES_PERFORMED[]
BEST_NEXT_SOURCE if insufficient
RATIONALE
```

Sector overlays may substitute economically correct inputs where industrial metrics are not applicable.

---

# 15. SUFFICIENT — EXACT MEANING

For a required block:

```text
DD_INPUT_STATUS = SUFFICIENT
```

only if all three are true:

```text
1. MANDATORY COVERAGE
   The evidence types necessary to analyze the block are present.

2. EVIDENCE ADEQUACY
   Evidence quality / claim fit / freshness / independence is adequate for the material questions.

3. NO MATERIAL BLOCKING GAP
   No unresolved missing item or conflict prevents a defensible later judgment.
```

This does not require perfect information.

It requires sufficient information for an honest conclusion, including:

```text
SUPPORTED
NOT_SUPPORTED
MIXED
LOW_CONFIDENCE
NOT_ASSESSABLE
```

where the frozen Deep Dive method allows such outcomes.

---

# 16. BLOCK-SPECIFIC MINIMUM RESEARCH QUESTIONS

The Research Stage does not answer these analytically; it ensures the evidence exists to answer them later.

## 16.1 IDENTITY / PIT

Evidence sufficient to establish:

```text
issuer
security/share class
listing
reporting currency
fiscal period
share-count basis
material corporate actions
reference-period boundaries
```

## 16.2 BUSINESS MODEL

Evidence sufficient to map:

```text
who pays
for what
pricing mechanism
volume mechanism
recurrence
segments
geographies
cost drivers
capital requirements
organic vs acquired composition
```

## 16.3 MOAT

Evidence sufficient to test:

```text
claimed mechanism
external / behavioral corroboration
economic consequence
customer alternatives
replication / substitution
competitive dynamics
entry / exit evidence
trend / durability questions
```

## 16.4 RUNWAY

Evidence sufficient to distinguish:

```text
TAM
serviceable market
realistic capture pool
penetration
replacement vs new demand
capacity / capital constraints
competitive constraints
organizational constraints
pricing vs volume growth
core vs optionality growth
```

## 16.5 RETURN QUALITY

Evidence sufficient to reconstruct or validly substitute:

```text
NOPAT basis
invested capital basis
acquisition capital if material
historical normalized returns
marginal / cohort return evidence
reinvestment requirements
interpretability / attribution constraints
```

## 16.6 FCF / FORENSIC

Evidence sufficient to test:

```text
cash generation
working capital
maintenance vs growth investment
SBC / dilution
capitalized / expensed intangibles where relevant
one-offs
receivables
inventory
provisions
accruals
related parties
cash taxes
owner-economics adjustments
```

## 16.7 CAPITAL ALLOCATION

Evidence sufficient to reconstruct:

```text
organic reinvestment
M&A
buybacks
issuance
dividends
debt decisions
historical returns on material deployment
management rationale vs realized outcome
```

## 16.8 MANAGEMENT / GOVERNANCE

Evidence sufficient to evaluate later:

```text
ownership
board structure
incentives
remuneration metrics
capital-allocation accountability
related parties
minority-holder treatment
succession / key-person exposure
material governance events
```

## 16.9 OUTSIDE VIEW

Evidence sufficient for relevant base rates / analogues / failure modes / industry economics.

## 16.10 RISK / RESILIENCE

Evidence sufficient to map material causal risks, balance-sheet capacity, customer / supplier concentration, regulation, disruption, cyclicality and operational resilience.

## 16.11 VALUATION INPUTS

Evidence sufficient to later value the company, including as applicable:

```text
normalized earnings / cash-flow history
share count
net debt / excess cash / claims
capital structure
market reference data
segment economics
credible normalization inputs
reinvestment needs
mature economics inputs
relevant market / peer / historical context
```

Research does not calculate the final valuation here.

---

# 17. GAP-CLOSING LOOP

If any required block is insufficient:

```text
INSUFFICIENT
→ TARGETED SEARCH
→ SOURCE DIVERSIFICATION
→ NEGATIVE / CONTRADICTORY SEARCH
→ ROOT-SOURCE RECOVERY
→ CONFLICT RESOLUTION ATTEMPT
→ RE-EVALUATION
```

Continue until either:

```text
SUFFICIENT
```

or:

```text
REASONABLY AVAILABLE SOURCES EXHAUSTED
```

Research must not continue indefinitely merely to force `SUFFICIENT`.

---

# 18. CRITICAL INPUT DOCTRINE

A missing input is critical when it is necessary to a Core future judgment or can plausibly reverse the future conclusion and no robust alternative research path avoids it.

Before asking the user for help, Research must have reasonably attempted independent retrieval.

If still unavailable:

```text
CRITICAL_INPUT_MISSING
→ RESEARCH_STAGE_STATUS = PAUSED
→ GLOBAL PAUSE
→ REQUEST USER ASSISTANCE
```

The request must specify:

```text
EXACT DOCUMENT / DATA REQUIRED
WHY IT IS CRITICAL
WHAT SEARCHES WERE ATTEMPTED
ACCEPTABLE SUBSTITUTE
WHAT CANNOT PROCEED WITHOUT IT
```

Research does not continue other blocks while globally paused.

---

# 19. USER RESUME UX

When paused for a critical item, the user may upload the requested file in the same Research discussion and write:

```text
voilà
```

Research must:

```text
1. IDENTIFY the supplied item.
2. VERIFY relevance / date / provenance.
3. REGISTER it.
4. RE-EVALUATE the blocker.
5. UPDATE the affected DD input block.
6. RESUME exactly from the paused state if the blocker is resolved.
```

No new bootstrap is required for same-discussion resumption.

---

# 20. LOW-DISCLOSURE COMPANIES

Low disclosure is not a negative business-quality signal.

```text
LOW DISCLOSURE
≠ BAD BUSINESS

UNKNOWN
≠ BAD
```

If required input remains unavailable after adequate research:

```text
DD_INPUT_STATUS = INSUFFICIENT
```

This blocks Deep Dive admission for the affected required scope but does not automatically produce an investment rejection.

---

# 21. SECTOR / BUSINESS-MODEL ADAPTATION

Research must adapt inputs to economically relevant methods.

Examples include:

```text
SOFTWARE
MARKETPLACE
INDUSTRIAL
INSTALLED BASE / MEDTECH
DATA / TESTING / CERTIFICATION
BANK
INSURANCE
SERIAL ACQUIRER
LUXURY / BRAND
CYCLICAL / COMMODITY-LIKE
```

Where a raw industrial metric is not applicable, collect the evidence required for the frozen sector substitute rather than forcing the industrial metric.

`NOT_APPLICABLE` is valid only when the method provides an economically appropriate substitute or the input truly has no relevance.

---

# 22. REFRESH RESEARCH

For REFRESH runs, Research first performs:

```text
WHAT CHANGED SINCE LAST CANONICAL SNAPSHOT?
```

Search for material deltas in:

```text
financial reporting
guidance
business model
management
governance
capital allocation
M&A
competition
products / technology
regulation
market structure
material risks
valuation inputs
prior invalidation / reactivation triggers
```

Then classify under the frozen refresh architecture:

```text
PRICE_ONLY_DELTA
ROUTINE_FUNDAMENTAL_DELTA
FULL_REFRESH_REQUIRED
```

Research does not change this classifier’s semantics.

---

# 23. REFRESH SCOPE

## 23.1 PRICE_ONLY_DELTA

Research does not mechanically reopen fundamental evidence blocks solely because price moved.

If no fundamental evidence refresh is needed:

```text
RESEARCH_SCOPE = MINIMAL / NOT_REQUIRED FOR FUNDAMENTALS
```

and the run may proceed to the authorized valuation / activation path as defined elsewhere.

## 23.2 ROUTINE_FUNDAMENTAL_DELTA

Reassess:

```text
AFFECTED INPUT BLOCKS
+
MATERIAL DOWNSTREAM DEPENDENCIES
```

Only reopened required blocks must regain `SUFFICIENT` before affected Deep Dive work resumes.

## 23.3 FULL_REFRESH_REQUIRED

Re-establish all required DD input blocks as if conducting a fresh institutional evidence pass, while using prior canonical work as a research map rather than presumed truth.

---

# 24. PRIOR CANONICAL RESEARCH

Core rule:

```text
PREVIOUS CANONICAL RESEARCH
= KNOWLEDGE BASE
≠ CURRENT EVIDENCE BY DEFAULT
```

Prior work may accelerate source discovery and hypothesis formation.

Material inherited conclusions relied upon in the new run must be revalidated against current evidence.

Useful execution labels:

```text
REVALIDATED
UPDATED
SUPERSEDED
INVALIDATED
```

Do not require pointless re-tagging of every immaterial historical fact.

---

# 25. RESEARCH MAY DISCOVER BAD NEWS

Research must not stop or soften evidence because it harms the thesis.

Examples:

```text
customer loss
regulatory change
accounting concern
competitor replication
pricing pressure
share loss
governance issue
poor acquisition outcome
technology substitution
```

must be registered normally.

Research is evidence-seeking, not thesis-defending.

---

# 26. RESEARCH CANNOT SCORE

Forbidden in Research Stage:

```text
MOAT_SCORE
RUNWAY_SCORE
RETURN_QUALITY_SCORE
OQS
OVS
INVESTMENT_SCORE
OROTITAN_STATUS
```

Research may note what evidence would later support or challenge a block, but may not pre-score it.

---

# 27. RESEARCH CANNOT VALUE

Forbidden as final Research output:

```text
FAIR VALUE
PRICE TARGET
FINAL DCF
FINAL EXPECTED RETURN
FINAL MOS
```

Research may collect valuation inputs and identify normalization questions.

Research may perform limited sanity calculations only when necessary to validate data consistency, not to issue the investment conclusion.

---

# 28. ANALYSIS INPUT LOCK

When Research reaches completion, create an `ANALYSIS_INPUT_LOCK` identifying the exact evidence state admitted to Deep Dive.

Minimum conceptual fields:

```text
RUN_ID
COMPANY_ID
DATA_CUTOFF
RESEARCH_STAGE_CONTRACT_VERSION
EVIDENCE_LEDGER_VERSION
SOURCE_MANIFEST_VERSION
DD_INPUT_SUFFICIENCY_VERSION
OPEN_NONCRITICAL_GAPS[]
OPEN_MATERIAL_CONFLICTS[]
CRITICAL_BLOCKERS[]
READY_FOR_DEEP_DIVE
CREATED_AT
```

This is an execution artifact, not an analytical verdict.

---

# 29. READY_FOR_DEEP_DIVE

For INITIAL / FULL_REFRESH_REQUIRED:

```text
READY_FOR_DEEP_DIVE = YES
```

only when every required DD input block is:

```text
SUFFICIENT
or validly NOT_APPLICABLE
```

and:

```text
NO CRITICAL BLOCKER
NO MATERIAL UNRESOLVED CONFLICT THAT PREVENTS HONEST ANALYSIS
PRE_FLIGHT / VERSION / CUTOFF INTEGRITY = PASS
```

For targeted refresh, apply the same rule to the reopened required scope and material downstream dependencies.

Research itself may make this gate decision; no mandatory second model is required.

Before `YES`, perform a formal self-audit.

---

# 30. SELF-AUDIT BEFORE READY = YES

Research must ask:

```text
Did we cover every required input block?
Did we use fit-for-purpose sources for material claims?
Did we actively search for contradictory evidence?
Did we recover root sources where reasonably possible?
Did we register material conflicts?
Did we keep hypotheses separate from verdicts?
Did we avoid post-cutoff contamination?
Did we preserve unknowns honestly?
Did we avoid scoring / valuation?
Did we identify every critical missing item?
Would Deep Dive be able to reach an honest negative conclusion with this evidence pack?
```

If any material answer is `NO`:

```text
READY_FOR_DEEP_DIVE != YES
```

---

# 31. AUTHORITATIVE RESEARCH ARTIFACTS

At completion, persist at minimum conceptually:

```text
1. RESEARCH_SOURCE_MANIFEST
2. EVIDENCE_LEDGER
3. CONFLICT_LEDGER references / records
4. MATERIAL_RESEARCH_HYPOTHESIS_REGISTER
5. RESEARCH_GAP_REGISTER
6. DD_INPUT_SUFFICIENCY_RECORD
7. ANALYSIS_INPUT_LOCK
8. RESEARCH_STAGE_MANIFEST
```

The exact file layout is an implementation detail.

Do not duplicate frozen ledger semantics in incompatible schemas.

---

# 32. SOURCE MANIFEST

The source manifest should allow a later stage to know what was searched and used.

Minimum conceptual fields:

```text
SOURCE_ID
TITLE / DESCRIPTION
SOURCE_TYPE
ISSUER / PUBLISHER
SOURCE_DATE
DATA_PERIOD
ROOT_SOURCE_ID if derivative
URL / FILE_REFERENCE
DISCOVERY_ROUTE
ACCESS_STATUS
INCLUDED_IN_EVIDENCE_LEDGER
NOTES / LIMITATIONS
```

The source manifest is broader than the Evidence Ledger: not every discovered source needs to become material evidence.

---

# 33. RESEARCH GAP REGISTER

Every material unresolved research gap should record:

```text
GAP_ID
AFFECTED_INPUT_BLOCK
QUESTION
MATERIALITY
SEARCHES_ATTEMPTED[]
BEST_NEXT_SOURCE
STATUS
WHY_NOT_RESOLVED
IMPACT_ON_READY_FOR_DEEP_DIVE
```

Use it to avoid repeatedly searching the same dead end without learning.

---

# 34. STAGE FINALIZATION

Research may be `COMPLETE` only after:

```text
1. REQUIRED RESEARCH WORK COMPLETE
2. SELF-AUDIT COMPLETE
3. AUTHORITATIVE ARTIFACTS GENERATED
4. ARTIFACTS PERSISTED / VERSIONED
5. REGISTRY RECONCILED
6. RESEARCH_STAGE_STATUS UPDATED
7. READY_FOR_DEEP_DIVE DECLARED
8. HUMAN SUMMARY PRODUCED
9. PILOTAGE HANDOFF PRODUCED
10. STOP AT STAGE BOUNDARY
```

If persistence fails:

```text
RESEARCH_STAGE_STATUS != COMPLETE
```

A narrative answer alone never completes the stage.

---

# 35. HUMAN SUMMARY

At completion, provide a concise 10–15 line user summary covering:

```text
what was gathered
material evidence strengths
important contradictions / negative evidence
important non-blocking gaps
overall evidence quality
any critical item supplied by the user and resolved
READY_FOR_DEEP_DIVE status
```

The summary is for human understanding only.

```text
HUMAN SUMMARY
≠ DEEP DIVE INPUT AUTHORITY
```

---

# 36. PILOTAGE HANDOFF

Emit a compact fallback routing record:

```text
COMPANY
RUN_ID
STAGE = RESEARCH
RESEARCH_STAGE_STATUS
READY_FOR_DEEP_DIVE
DATA_CUTOFF
AUTHORITATIVE_ARTIFACT_IDS / VERSIONS
CRITICAL_BLOCKERS
OPEN_NONCRITICAL_GAPS
NEXT_STAGE
```

Normal path:

```text
Pilotage retrieves registry state directly.
```

Fallback path:

```text
User copies handoff.
```

The handoff is not analytical evidence.

---

# 37. FAIL-CLOSED RULES

At minimum:

```text
CONTRACT VERSION MISMATCH
→ STOP

RUN_ID MISMATCH
→ STOP

DATA_CUTOFF VIOLATION
→ EXCLUDE SOURCE / REQUIRE NEW RUN IF MATERIAL

MISSING CRITICAL INPUT
→ PAUSE

MATERIAL UNRESOLVED CONFLICT BLOCKING HONEST ANALYSIS
→ DD INPUT BLOCK = INSUFFICIENT

REQUIRED INPUT BLOCK = INSUFFICIENT
→ READY_FOR_DEEP_DIVE = NO

PERSISTENCE / REGISTRY FAILURE
→ RESEARCH_STAGE_STATUS != COMPLETE

USER SUMMARY ONLY
→ NOT ACCEPTED AS STAGE ARTIFACT
```

---

# 38. ACCEPTANCE TESTS REQUIRED BEFORE FREEZE

Validate at minimum:

```text
R01 Initial imposed company with rich disclosures
R02 Low-disclosure small cap
R03 User uploads partial document set
R04 Critical document unavailable then user provides it with "voilà"
R05 Material issuer vs customer evidence conflict
R06 Root source recoverable from secondary article
R07 Root source unavailable
R08 Post-cutoff source discovered
R09 Famous company / anti-fame
R10 Strong issuer claims but weak external corroboration
R11 Negative customer evidence harms thesis
R12 Sector with industrial ROIC not applicable
R13 Serial acquirer requiring acquisition evidence
R14 Marketplace with near-zero invested capital
R15 Initial run with one input block insufficient
R16 All blocks sufficient but likely future negative moat verdict
R17 Routine fundamental refresh
R18 Full refresh required
R19 Price-only delta
R20 Prior canonical conclusion contradicted by new evidence
R21 Persistence failure after research complete
R22 Evidence Ledger / source manifest mismatch
R23 Material conflict left unresolved
R24 Research tries to score company
R25 Research tries to issue price target
R26 Human summary used instead of artifacts
```

Required invariants:

```text
NO ANALYTICAL VERDICT LEAKAGE
NO SCORING
NO FINAL VALUATION
NO POST-CUTOFF CONTAMINATION
NO USER-AS-DEFAULT-DOCUMENT-COLLECTOR
NO SILENT CONFLICT RESOLUTION
NO SUMMARY-AS-AUTHORITY
NO DEEP DIVE ADMISSION WITH REQUIRED INSUFFICIENT BLOCK
```

---

# 39. CURRENT STATUS

```text
DOCUMENT = OROTITAN_RESEARCH_STAGE_CONTRACT_V1_FREEZE_V1.0
STATUS = FROZEN
FREEZE_VERSION = 1.0
FREEZE_DATE = 2026-09-12
METHODOLOGY_CHANGE = NO

FREEZE BASIS:
→ CONTRACT v0.1
→ TARGETED_VALIDATION_v0.1 = PASS
→ USER_APPROVAL = YES

NEXT:
→ BUILD + VALIDATE DEEP_DIVE_STAGE_CONTRACT
```
